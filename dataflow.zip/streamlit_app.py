# streamlit_app.py

import streamlit as st
import os
import sys
import shutil
import pandas as pd
import subprocess
import time
import uuid
import io
import json
from pathlib import Path
from dotenv import load_dotenv
from datetime import datetime

# --- Local Project Imports ---
from config import (
    CRAWL_CACHE_DIR, KNOWLEDGE_CACHE_DIR, OUTPUT_DIR, VECTOR_DB_PATH, APP_VERSION,
    SUPABASE_URL, SUPABASE_KEY
)
from schemas import CHOICE_OPTIONS
import db_manager

# --- Automatic .env Loading ---
load_dotenv(override=True)
SUPABASE_CONFIGURED = bool(SUPABASE_URL and SUPABASE_KEY)

# --- App Directories ---
TEMP_DIR = Path("./temp_streamlit_files")
TEMP_DIR.mkdir(exist_ok=True)
LOG_DIR = Path("./streamlit_logs")
LOG_DIR.mkdir(exist_ok=True)


# --- App State Management ---
def initialize_session_state():
    """Initializes all necessary session state variables."""
    if 'view' not in st.session_state:
        st.session_state.view = "home"
    if 'agent_status' not in st.session_state:
        st.session_state.agent_status = "Idle"
    if 'active_process' not in st.session_state:
        st.session_state.active_process = None
    if 'log_file' not in st.session_state:
        st.session_state.log_file = None
    if 'final_log_content' not in st.session_state:
        st.session_state.final_log_content = ""
    if 'output_files' not in st.session_state:
        st.session_state.output_files = []
    if 'files_before_run' not in st.session_state:
        st.session_state.files_before_run = set()
    if 'db_events' not in st.session_state:
        st.session_state.db_events = []
    if 'db_selected_event' not in st.session_state:
        st.session_state.db_selected_event = None
    # --- Intent Flags for Robust Button Clicks ---
    if 'start_crawl4ai_flag' not in st.session_state:
        st.session_state.start_crawl4ai_flag = False
    if 'start_calendarcrawl_flag' not in st.session_state:
        st.session_state.start_calendarcrawl_flag = False
    if 'start_gemini_flag' not in st.session_state:
        st.session_state.start_gemini_flag = False


# --- Helper Functions ---
def read_log_file():
    if st.session_state.log_file and Path(st.session_state.log_file).exists():
        try:
            with open(st.session_state.log_file, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception:
            return "Reading log file..."
    return "Process has not started yet."

def get_files_in_dir(directory):
    dir_path = Path(directory)
    if not dir_path.is_dir():
        dir_path.mkdir(exist_ok=True)
    return {str(f) for f in dir_path.glob("*.csv")}

def start_agent_process(command):
    st.session_state.output_files = []
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    st.session_state.log_file = LOG_DIR / f"run_{timestamp}.log"
    st.session_state.final_log_content = ""
    st.session_state.files_before_run = get_files_in_dir(OUTPUT_DIR)
    try:
        with open(st.session_state.log_file, 'w', encoding='utf-8') as log_f:
            process = subprocess.Popen(
                command, stdout=log_f, stderr=subprocess.STDOUT, text=True,
                encoding='utf-8', errors='replace'
            )
        st.session_state.active_process = process
        st.session_state.agent_status = "Running"
    except Exception as e:
        st.error(f"Error during agent setup: {e}")

def change_view(view_name):
    st.session_state.view = view_name

# --- ACTION PROCESSING LOGIC (CALLED AFTER UI RENDER) ---

def process_crawl4ai_start():
    """Reads state and launches the Web Research Agent."""
    if st.session_state.agent_status == "Running": return

    input_method = st.session_state.get('crawl4ai_input_method', 'File Upload')
    max_events_str_web = st.session_state.get('max_events_web', "")
    temp_input_path = TEMP_DIR / "races.json"
    input_ready = False

    if input_method == "File Upload":
        input_file = st.session_state.get('web_agent_uploader')
        if not input_file:
            st.error("Please upload an input data file.")
            return
        try:
            file_contents = input_file.getvalue()
            if input_file.name.lower().endswith('.csv'):
                df = pd.read_csv(io.BytesIO(file_contents))
                df.to_json(temp_input_path, orient='records', indent=4)
            elif input_file.name.lower().endswith('.xlsx'):
                df = pd.read_excel(io.BytesIO(file_contents))
                df.to_json(temp_input_path, orient='records', indent=4)
            else:
                with open(temp_input_path, "wb") as f:
                    f.write(file_contents)
            input_ready = True
        except Exception as e:
            st.error(f"Error preparing input file: {e}")
    else: # Manual Entry
        manual_event_names = st.session_state.get('manual_event_names', "")
        event_type = st.session_state.get('manual_event_type', "Run")
        if not manual_event_names.strip():
            st.error("Please enter at least one event name.")
            return
        try:
            event_list = [name.strip() for name in manual_event_names.strip().split('\n') if name.strip()]
            races_data = [{"Festival": name, "Type": event_type} for name in event_list]
            with open(temp_input_path, 'w', encoding='utf-8') as f:
                json.dump(races_data, f, indent=4)
            input_ready = True
        except Exception as e:
            st.error(f"Error preparing manual input: {e}")

    if input_ready:
        command = [sys.executable, "-u", "main.py", "--mode", "web_analyst", "--output-dir", OUTPUT_DIR, "--input-file", str(temp_input_path)]
        if max_events_str_web.isdigit():
            command.extend(["--max-events", max_events_str_web])
        start_agent_process(command)
        st.rerun()

def process_calendarcrawl_start():
    """Reads state and launches the Pre-scraped Data Processor."""
    if st.session_state.agent_status == "Running": return

    calendar_mode = st.session_state.get('cal_agent_mode', 'Crawl Cycling Calendar')
    max_events_str_cal = st.session_state.get('max_events_cal', "")
    uploaded_files_cal = st.session_state.get('cal_agent_uploader', [])

    if calendar_mode == "Process Default Websites" and not uploaded_files_cal:
        st.error("Please upload at least one JSON file for this mode.")
        return
    
    temp_input_paths_cal = []
    if uploaded_files_cal:
        for up_file in uploaded_files_cal:
            path = TEMP_DIR / up_file.name
            with open(path, "wb") as f:
                f.write(up_file.getvalue())
            temp_input_paths_cal.append(str(path))

    mode_flag = "calendar_crawl" if calendar_mode == "Crawl Cycling Calendar" else "default_websites"
    command = [sys.executable, "-u", "main.py", "--mode", mode_flag, "--output-dir", OUTPUT_DIR]
    
    if temp_input_paths_cal:
        command.append("--input-files")
        command.extend(temp_input_paths_cal)
    if max_events_str_cal.isdigit():
        command.extend(["--max-events", max_events_str_cal])
    
    start_agent_process(command)
    st.rerun()

def process_gemini_start():
    """Reads state and launches the Gemini Image Processor."""
    if st.session_state.agent_status == "Running": return

    uploaded_images = st.session_state.get('gemini_uploader', [])
    if not uploaded_images:
        st.error("Please upload at least one image.")
        return

    run_id = uuid.uuid4()
    image_input_path = TEMP_DIR / f"gemini_input_{run_id}"
    image_input_path.mkdir(exist_ok=True)
    
    for image in uploaded_images:
        with open(image_input_path / image.name, "wb") as f:
            f.write(image.getbuffer())

    command = [sys.executable, "-u", "gemini.py", "--output-dir", OUTPUT_DIR, "--input-dir", str(image_input_path)]
    start_agent_process(command)
    st.rerun()

# --- UI RENDER FUNCTIONS ---

def show_home_screen():
    """Renders the main welcome screen with consistent UI."""
    st.title("🤖 Welcome to the Crawl4AI Unified Agent System")
    st.markdown(f"**Version:** `{APP_VERSION}`")
    st.write("---")

    if not SUPABASE_CONFIGURED:
        st.error("**Supabase Not Configured!** The application will run in local-only mode. Database features will be disabled. Please add Supabase credentials to your `.env` file.", icon="⚠️")

    st.subheader("Please select a module to begin:")
    st.write("")

    col1, col2, col3 = st.columns(3, gap="large")

    with col1:
        with st.container(border=True):
            st.header("🌐 Web Research Agent")
            st.markdown("**(Crawl4AI)**")
            st.write("Provide event names, and this agent will autonomously search the web, validate sources, and perform a deep AI analysis to extract detailed information.")
            st.button("Launch Web Agent", on_click=change_view, args=("crawl4ai",), use_container_width=True, type="primary")

    with col2:
        with st.container(border=True):
            st.header("📄 Pre-scraped Data Processor")
            st.markdown("**(CalendarCrawl)**")
            st.write("Process data from pre-scraped JSON files or crawl a specific, known event calendar URL to extract information from direct links.")
            st.button("Launch Data Processor", on_click=change_view, args=("calendarcrawl",), use_container_width=True, type="primary")
            
    with col3:
        with st.container(border=True):
            st.header("🖼️ Gemini Image Processor")
            st.markdown("**(Image Analysis)**")
            st.write("Upload event posters or banners, and this agent will use Google Gemini Vision to analyze the images and extract key event details.")
            st.button("Launch Image Processor", on_click=change_view, args=("gemini",), use_container_width=True, type="primary")

    st.write("---")
    
    with st.container(border=True):
        st.header("🗃️ Database Manager")
        st.write("View, manage, and delete the persisted knowledge and crawl cache data stored in your Supabase project.")
        st.button("Open Database Manager", on_click=change_view, args=("db_manager",), use_container_width=True, type="primary", disabled=not SUPABASE_CONFIGURED)


def show_agent_ui():
    """Renders the main agent control panel and log viewer UI."""
    is_running = st.session_state.agent_status == "Running"

    with st.sidebar:
        st.header("Configuration")
        st.success("✅ `.env` file loaded.") if Path(".env").exists() else st.error("❌ `.env` file not found!")
        st.success("☁️ Supabase configured.") if SUPABASE_CONFIGURED else st.warning("⚠️ Supabase not configured.")

    col1, col2 = st.columns([0.45, 0.55], gap="large")

    with col1:
        st.button("⬅️ Back to Home", on_click=change_view, args=("home",), disabled=is_running)
        st.header("Agent Control Panel")

        if st.session_state.view == "crawl4ai": render_crawl4ai_controls()
        elif st.session_state.view == "calendarcrawl": render_calendarcrawl_controls()
        elif st.session_state.view == "gemini": render_gemini_controls()

        st.header("📂 Results")
        with st.container(border=True):
            if st.session_state.agent_status == "Finished":
                if st.session_state.output_files:
                    st.success("Processing finished! You can now download your files.")
                    for file_path in st.session_state.output_files:
                        file = Path(file_path)
                        with open(file, "rb") as fp:
                            st.download_button(label=f"📄 Download {file.name}", data=fp, file_name=file.name, mime="text/csv", key=f"dl_{file.name}", use_container_width=True)
                else:
                    st.warning("Process finished, but no new output files were generated.")
            else:
                st.info("Results from the current run will appear here after completion.")

    with col2:
        st.header("Live Status & Logs")
        status = st.session_state.agent_status
        if status == "Idle": st.info("📊 **Status:** Waiting to start a process.")
        elif status == "Running": st.warning("⚙️ **Status:** Running... Logs refresh automatically.")
        elif status == "Finished": st.success("✅ **Status:** Process finished successfully.")
        elif status == "Terminated": st.error("🛑 **Status:** Process stopped by user.")
        elif status == "Error": st.error("🔥 **Status:** Process failed with an error. Check logs.")

        if is_running:
            if st.button("⏹️ Stop Active Process", use_container_width=True):
                if st.session_state.active_process:
                    st.session_state.active_process.terminate()
                    time.sleep(1)
                    st.session_state.agent_status = "Terminated"
                    st.session_state.active_process = None
                    st.rerun()

        log_content = st.session_state.final_log_content if status != "Running" else read_log_file()
        st.text_area("Log Output", value=log_content, height=500, disabled=True, key="log_area")


def show_db_manager_ui():
    st.button("⬅️ Back to Home", on_click=change_view, args=("home",))
    st.title("🗃️ Database & Cache Manager")
    st.info("Here you can view data saved in Supabase and manage both local and remote caches.")

    col1, col2 = st.columns([0.4, 0.6], gap="large")

    with col1:
        st.subheader("Cached Events")
        if st.button("🔄 Refresh Event List"):
            st.session_state.db_events = []
        
        if not st.session_state.db_events:
            with st.spinner("Fetching events from Supabase..."):
                st.session_state.db_events = db_manager.list_all_events()

        if not st.session_state.db_events:
            st.warning("No events found in the Supabase knowledge cache.")
        else:
            with st.container(height=400):
                st.radio("Select an event to manage:", options=st.session_state.db_events, key="db_selected_event", label_visibility="collapsed")

        st.write("---")
        st.subheader("Global Cache Utilities")
        with st.container(border=True):
            st.write("These actions clear the entire local cache for all events.")
            if st.button("🗑️ Clear ALL Local Crawl Cache"):
                try:
                    if Path(CRAWL_CACHE_DIR).exists(): shutil.rmtree(CRAWL_CACHE_DIR)
                    Path(CRAWL_CACHE_DIR).mkdir(exist_ok=True)
                    st.toast("Cleared Local Crawl Cache.", icon="✅")
                except Exception as e: st.error(f"Error: {e}")
            if st.button("🗑️ Clear ALL Local Knowledge Cache"):
                try:
                    if Path(KNOWLEDGE_CACHE_DIR).exists(): shutil.rmtree(KNOWLEDGE_CACHE_DIR)
                    Path(KNOWLEDGE_CACHE_DIR).mkdir(exist_ok=True)
                    st.toast("Cleared Local Knowledge Cache.", icon="✅")
                except Exception as e: st.error(f"Error: {e}")
            if st.button("🗑️ Clear ENTIRE Local Vector DB"):
                try:
                    if Path(VECTOR_DB_PATH).exists(): shutil.rmtree(VECTOR_DB_PATH)
                    Path(VECTOR_DB_PATH).mkdir(exist_ok=True)
                    st.toast("Cleared Local Vector DB.", icon="✅")
                except Exception as e: st.error(f"Error: {e}")

    with col2:
        st.subheader("Event Details & Management")
        if st.session_state.db_selected_event:
            with st.container(border=True):
                with st.spinner(f"Fetching details for '{st.session_state.db_selected_event}'..."):
                    event_data = db_manager.get_event_details(st.session_state.db_selected_event)
                
                if event_data:
                    st.subheader("Supabase Knowledge Cache")
                    st.json(event_data, expanded=False)
                    st.write("---")
                    st.subheader("Local Cache Management")
                    st.warning("This will delete the **local cache** for this event, forcing a complete re-analysis on the next run. It **does NOT** affect the data saved in Supabase.", icon="ℹ️")
                    if st.button("Clear Local Cache for this Event"):
                        with st.spinner(f"Clearing local cache for '{st.session_state.db_selected_event}'..."):
                            success, message = db_manager.clear_local_event_cache(st.session_state.db_selected_event)
                        if success: st.success(message)
                        else: st.error(message)
                    st.write("---")
                    st.subheader("⚠️ Danger Zone: Supabase Deletion")
                    confirm_delete = st.checkbox(f"I want to permanently delete all data for '{st.session_state.db_selected_event}' from Supabase.", key="delete_confirm")
                    if st.button("🔥 Hard Delete Event from Supabase", type="primary", disabled=not confirm_delete):
                        with st.spinner(f"Performing hard delete for '{st.session_state.db_selected_event}'..."):
                            success, message = db_manager.delete_event_from_supabase(st.session_state.db_selected_event)
                        if success:
                            st.success(message)
                            st.session_state.db_events = []
                            st.session_state.db_selected_event = None
                            st.rerun()
                        else:
                            st.error(message)
                else:
                    st.error("Could not retrieve details for the selected event.")
        else:
            st.info("Select an event from the list to see its cached data and management options.")

def render_crawl4ai_controls():
    st.subheader("🌐 Web Research Agent")
    st.info("This agent takes event names, searches the web, and performs deep analysis to extract data.")
    is_running = st.session_state.agent_status == "Running"
    with st.container(border=True):
        st.subheader("1. Input Method")
        st.radio("Choose how to provide event names:", ["File Upload", "Manual Entry"], horizontal=True, label_visibility="collapsed", key='crawl4ai_input_method', disabled=is_running)
        if st.session_state.crawl4ai_input_method == "File Upload":
            st.subheader("Upload Event List File (JSON/CSV/XLSX)")
            st.file_uploader("Upload Event List File", type=['json', 'csv', 'xlsx'], key="web_agent_uploader", disabled=is_running, label_visibility="collapsed")
        else:
            st.subheader("Enter Event Details")
            st.selectbox("Event Type (for all events below)", options=CHOICE_OPTIONS["type"], index=4, key='manual_event_type', disabled=is_running)
            st.text_area("Event Names (one per line)", placeholder="Event Name 1\nEvent Name 2", height=150, key='manual_event_names', disabled=is_running)
        st.text_input("Max events to process (optional)", key="max_events_web", help="Limit the number of events to process from the input.", disabled=is_running)
        st.caption(f"Output will be saved to: **{os.path.abspath(OUTPUT_DIR)}**")
    with st.container(border=True):
        st.subheader("2. Execution")
        def set_start_flag(): st.session_state.start_crawl4ai_flag = True
        st.button("▶️ Start Web Research Agent", on_click=set_start_flag, disabled=is_running or not Path(".env").exists(), use_container_width=True, type="primary")

def render_calendarcrawl_controls():
    st.subheader("📄 Pre-scraped Data Processor")
    st.info("This agent processes data from pre-scraped files or directly from a specific calendar URL.")
    is_running = st.session_state.agent_status == "Running"
    with st.container(border=True):
        st.subheader("1. Mode")
        st.selectbox("Select Mode", ["Crawl Cycling Calendar", "Process Default Websites"], key='cal_agent_mode', disabled=is_running)
        st.text_input("Max events to process (optional)", key="max_events_cal", help="Limit the number of events to process.", disabled=is_running)
    with st.container(border=True):
        st.subheader("2. Inputs")
        if st.session_state.get('cal_agent_mode') == "Process Default Websites":
            st.file_uploader("Upload Pre-scraped JSON File(s)", type=['json'], accept_multiple_files=True, key="cal_agent_uploader", disabled=is_running)
        else:
            st.success("This mode will automatically crawl `audaxindia.in`. No input file is needed.")
    with st.container(border=True):
        st.subheader("3. Execution")
        def set_start_flag(): st.session_state.start_calendarcrawl_flag = True
        st.button("▶️ Start Pre-scraped Data Processor", on_click=set_start_flag, disabled=is_running or not Path(".env").exists(), use_container_width=True, type="primary")

def render_gemini_controls():
    st.subheader("🖼️ Gemini Image Processor")
    st.info("This agent analyzes images of event posters to extract key details.")
    is_running = st.session_state.agent_status == "Running"
    with st.container(border=True):
        st.subheader("1. Inputs")
        st.file_uploader("Upload Image Files", type=['png', 'jpg', 'jpeg'], accept_multiple_files=True, key='gemini_uploader', disabled=is_running)
        st.caption(f"Output will be saved to: **{os.path.abspath(OUTPUT_DIR)}**")
    with st.container(border=True):
        st.subheader("2. Execution")
        def set_start_flag(): st.session_state.start_gemini_flag = True
        st.button("▶️ Start Gemini Processor", on_click=set_start_flag, disabled=is_running or not Path(".env").exists(), use_container_width=True, type="primary")


# --- Main App Logic ---
st.set_page_config(page_title="Crawl4AI Unified System", layout="wide", initial_sidebar_state="auto")
initialize_session_state()

if st.session_state.view == "home":
    show_home_screen()
elif st.session_state.view == "db_manager":
    show_db_manager_ui()
else:
    show_agent_ui()

if st.session_state.start_crawl4ai_flag:
    st.session_state.start_crawl4ai_flag = False
    process_crawl4ai_start()
elif st.session_state.start_calendarcrawl_flag:
    st.session_state.start_calendarcrawl_flag = False
    process_calendarcrawl_start()
elif st.session_state.start_gemini_flag:
    st.session_state.start_gemini_flag = False
    process_gemini_start()

if st.session_state.agent_status == "Running":
    process = st.session_state.active_process
    if process and process.poll() is not None:
        time.sleep(1) 
        st.session_state.final_log_content = read_log_file()
        return_code = process.poll()
        st.session_state.agent_status = "Finished" if return_code == 0 else "Error"
        if return_code == 0:
            files_after_run = get_files_in_dir(OUTPUT_DIR)
            st.session_state.output_files = sorted(list(files_after_run - st.session_state.files_before_run))
        st.session_state.active_process = None
        st.rerun()
    else:
        time.sleep(5)
        st.rerun()