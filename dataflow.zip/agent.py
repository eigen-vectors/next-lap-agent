# agent.py

import os
import re
import json
import time
import hashlib
import sys
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import wraps

import requests
import dirtyjson
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer, CrossEncoder
from langchain_mistralai.chat_models import ChatMistralAI
from langchain_core.messages import HumanMessage
from markdown_it import MarkdownIt
from rank_bm25 import BM25Okapi

import spacy

from config import (
    MISTRAL_MODEL, MAX_RETRIES, DEBUG, MAX_CONCURRENT_CRAWLERS,
    TOP_N_URLS_TO_PROCESS, CRAWL_CACHE_DIR, EMBEDDING_MODEL, SPACY_MODEL,
    VECTOR_DB_PATH, CROSS_ENCODER_MODEL, RAG_CANDIDATE_POOL_SIZE,
    RAG_FINAL_EVIDENCE_COUNT, SUPABASE_CONFIGURED
)
from schemas import (
    DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS, INFERABLE_FIELDS, BLACKLISTED_DOMAINS
)
from supabase_client import get_knowledge_cache, set_knowledge_cache, download_from_storage, upload_to_storage

class AgentInitializationError(Exception):
    pass

def retry(retries=MAX_RETRIES, delay=5):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            for i in range(retries):
                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    if i < retries - 1:
                        is_rate_limit = "429" in str(e)
                        current_delay = delay * (2 ** i) if not is_rate_limit else delay * (3 ** i)
                        print(f"  [WARNING] Function '{f.__name__}' failed. Retrying in {current_delay:.1f}s...")
                        time.sleep(current_delay)
                    else:
                        print(f"  [ERROR] Function '{f.__name__}' failed after {retries} retries.");
                        return None
        return wrapper
    return decorator

class Field:
    def __init__(self, value=None, confidence=0.0, sources=None, inferred_by=""):
        self.value = value
        self.confidence = confidence
        self.sources = sources or []
        self.inferred_by = inferred_by
        self.last_updated = datetime.now(timezone.utc).isoformat()

    def to_dict(self):
        return {
            "value": self.value,
            "confidence": self.confidence,
            "sources": self.sources,
            "inferred_by": self.inferred_by,
            "last_updated": self.last_updated
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            value=data.get('value'),
            confidence=data.get('confidence', 0.0),
            sources=data.get('sources', []),
            inferred_by=data.get('inferred_by', '')
        )

class MistralAnalystAgent:
    def __init__(self, mistral_key_1: str, mistral_key_2: str, search_key: str, cse_id: str, schema: list):
        if not all([mistral_key_1, mistral_key_2, search_key, cse_id]):
            raise AgentInitializationError("One or more API keys (Mistral, Search) are missing.")

        self.llm_clients = [ChatMistralAI(api_key=key, model=MISTRAL_MODEL, temperature=0.0) for key in [mistral_key_1, mistral_key_2]]
        self.llm_client_index = 0
        self.search_api_key, self.cse_id, self.schema = search_key, cse_id, schema
        self.field_instructions = self._generate_field_instructions()
        self.invalid_years = [str(y) for y in range(2015, 2025)]

        print("[INFO] Initializing ML models and VectorDB...")
        try:
            self.nlp = spacy.load(SPACY_MODEL)
            print("  - [SUCCESS] spaCy model loaded successfully.")
        except (OSError, IOError) as e:
            error_msg = (f"[FATAL] Failed to load spaCy model '{SPACY_MODEL}'. "
                         f"Please run 'python -m spacy download {SPACY_MODEL}'. Error: {e}")
            raise AgentInitializationError(error_msg)

        chroma_settings = Settings(
            persist_directory=VECTOR_DB_PATH,
            anonymized_telemetry=False,
            is_persistent=True,
            allow_reset=True
        )
        self.chroma_client = chromadb.Client(chroma_settings)
        
        self.embedding_model = SentenceTransformer(EMBEDDING_MODEL)
        self.cross_encoder = CrossEncoder(CROSS_ENCODER_MODEL)
        self.md_parser = MarkdownIt()
        self.chroma_collection = None
        
        self.bm25_index = None
        self.mission_corpus = [] 
        self.corpus_map = {} 
        self.mission_inference_cache = {}
        print("[SUCCESS] Models and VectorDB initialized.")

    def shutdown(self):
        print("  - Shutting down ChromaDB client...")
        try:
            self.chroma_client.reset()
            print("  - ChromaDB client reset successfully.")
        except Exception as e:
            print(f"  - [WARNING] Error while shutting down ChromaDB client: {e}")

    def get_legacy_caching_key(self, event_name: str) -> str:
        base_name = re.sub(r'sprint|standard|olympic|full iron|half iron|70\.3', '', event_name, flags=re.IGNORECASE)
        return re.sub(r'[^a-z0-9]+', '-', base_name.lower()).strip('-')

    def get_caching_key(self, event_name: str, url: str = "") -> str:
        if not event_name: event_name = "unknown_event"
        base_name = re.sub(r'sprint|standard|olympic|full iron|half iron|70\.3', '', event_name, flags=re.IGNORECASE)
        slug = re.sub(r'[^a-z0-9]+', '-', base_name.lower()).strip('-')
        name_hash = hashlib.md5(slug.encode('utf-8')).hexdigest()[:8]
        url_hash = ""
        if url: url_hash = "-" + hashlib.md5(url.encode('utf-8')).hexdigest()[:8]
        safe_slug = slug[:40].strip('-')
        if not safe_slug: safe_slug = "event"
        return f"{safe_slug}-{name_hash}{url_hash}"

    def _generate_field_instructions(self) -> dict:
        instructions = {}
        for key in self.schema:
            if key in DEFAULT_BLANK_FIELDS: continue
            if key in CHOICE_OPTIONS:
                instructions[key] = f"Extract the data for '{key}'. MUST be one of: {', '.join(CHOICE_OPTIONS[key])}."
            else:
                instructions[key] = f"Extract the data for '{key}'."
        return instructions

    @retry()
    def _call_llm(self, prompt: str) -> str:
        client = self.llm_clients[self.llm_client_index]
        self.llm_client_index = (self.llm_client_index + 1) % len(self.llm_clients)
        messages = [HumanMessage(content=prompt)]
        response = client.invoke(messages)
        return response.content

    def _step_1a_initial_search(self, race_info: dict) -> list:
        event_name = race_info.get("Festival")
        print(f"\n[STEP 1A] Performing initial search for '{event_name}'")
        query = f'{event_name} 2025 OR 2026'
        try:
            url = "https://www.googleapis.com/customsearch/v1"
            params = {"key": self.search_api_key, "cx": self.cse_id, "q": query, "num": 10}
            response = requests.get(url, params=params)
            response.raise_for_status()
            return [{"title": i.get("title"), "link": i.get("link"), "snippet": i.get("snippet")} for i in response.json().get("items", [])]
        except requests.HTTPError as e:
            print(f"  - [ERROR] Google Search API call failed: {e}")
            return []

    def _step_1b_validate_and_select_urls(self, event_name: str, search_results: list) -> list:
        print("[STEP 1B] Validating search results with LLM...")
        prompt = f"Identify the most relevant websites for '{event_name}'. Select the single best 'primary_url' (official page) and up to three 'secondary_urls'.\n\nSearch Results:\n{json.dumps(search_results, indent=2)}\n\nResponse MUST be JSON: {{'primary_url': '...', 'secondary_urls': [...]}}"
        response_text = self._call_llm(prompt)
        try:
            match = re.search(r'\{.*?\}', response_text, re.DOTALL)
            if match:
                urls = dirtyjson.loads(match.group(0))
                primary = urls.get("primary_url")
                secondaries = urls.get("secondary_urls", [])
                final_urls = list(dict.fromkeys([u for u in ([primary] + secondaries if primary else secondaries) if u]))
                print(f"  - [SUCCESS] LLM selected {len(final_urls)} relevant URLs.")
                return final_urls[:TOP_N_URLS_TO_PROCESS]
        except Exception: pass
        
        salvaged_urls = re.findall(r'https?://[^\s"\'\)\],]+', response_text)
        if salvaged_urls:
            return list(dict.fromkeys(salvaged_urls))[:TOP_N_URLS_TO_PROCESS]
        return [r['link'] for r in search_results[:TOP_N_URLS_TO_PROCESS] if r.get('link')]

    @retry(retries=2, delay=10)
    def _get_content_from_url(self, url: str) -> str | None:
        url_hash = hashlib.md5(url.encode()).hexdigest()
        storage_file_path = f"{url_hash}.md"
        
        if SUPABASE_CONFIGURED:
            content = download_from_storage(storage_file_path)
            if content:
                if DEBUG: print(f"  - [SUCCESS] Found crawl cache in Supabase Storage for: {url}")
                return content
        
        local_cache_path = os.path.join(CRAWL_CACHE_DIR, f"{url_hash}.md")
        if os.path.exists(local_cache_path):
            if DEBUG: print(f"  - Using local cached content for: {url}")
            with open(local_cache_path, 'r', encoding='utf-8') as f: return f.read()
        
        print(f"  - No cache found. Crawling: {url}")
        try:
            api_url = f"https://r.jina.ai/{url}"
            response = requests.get(api_url, timeout=60)
            if response.status_code == 200 and response.text:
                content = response.text
                with open(local_cache_path, 'w', encoding='utf-8') as f: f.write(content)
                if SUPABASE_CONFIGURED:
                    upload_to_storage(storage_file_path, content)
                return content
            return None
        except requests.RequestException:
            return None

    def _chunk_and_index_text(self, text: str, url: str, event_id_str: str):
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        chunks = RecursiveCharacterTextSplitter(chunk_size=768, chunk_overlap=100).split_text(text)
        if not chunks: return
        
        chunk_ids = [f"{event_id_str}_{hashlib.md5(chunk.encode()).hexdigest()}" for chunk in chunks]
        unique_chunk_ids = list(set(chunk_ids))
        existing_chunks = self.chroma_collection.get(ids=unique_chunk_ids)
        existing_ids = set(existing_chunks['ids'])
        
        new_chunks_to_add = []
        start_idx = len(self.mission_corpus)

        for i, chunk_id in enumerate(chunk_ids):
            self.mission_corpus.append(chunks[i])
            self.corpus_map[start_idx + i] = {'id': chunk_id, 'snippet': chunks[i]}

            if chunk_id not in existing_ids:
                new_chunks_to_add.append({'id': chunk_id, 'chunk': chunks[i]})
                existing_ids.add(chunk_id)
        
        if new_chunks_to_add:
            print(f"    - Indexing {len(new_chunks_to_add)} new passages from {url}")
            new_ids = [item['id'] for item in new_chunks_to_add]
            new_documents = [item['chunk'] for item in new_chunks_to_add]
            new_embeddings = self.embedding_model.encode(new_documents).tolist()
            new_metadatas = [{"source_url": url, "event_id": event_id_str} for _ in new_ids]
            
            if new_ids:
                self.chroma_collection.add(ids=new_ids, embeddings=new_embeddings, documents=new_documents, metadatas=new_metadatas)

    def _build_bm25_index(self):
        if self.mission_corpus:
            tokenized_corpus = [doc.lower().split() for doc in self.mission_corpus]
            self.bm25_index = BM25Okapi(tokenized_corpus)

    def _retrieve_and_fuse_evidence(self, query: str, top_k: int) -> list[dict]:
        collection_count = self.chroma_collection.count()
        if collection_count == 0: return []
        
        n_results = min(top_k * 2, collection_count)
        query_embedding = self.embedding_model.encode(query).tolist()
        chroma_results = self.chroma_collection.query(query_embeddings=[query_embedding], n_results=n_results)
        
        vector_hits = {}
        if chroma_results['ids']:
            for rank, (doc_id, doc) in enumerate(zip(chroma_results['ids'][0], chroma_results['documents'][0])):
                vector_hits[doc_id] = {'snippet': doc, 'rank': rank}

        keyword_hits = {}
        if self.bm25_index:
            tokenized_query = query.lower().split()
            doc_scores = self.bm25_index.get_scores(tokenized_query)
            top_indices = sorted(range(len(doc_scores)), key=lambda i: doc_scores[i], reverse=True)[:top_k*2]
            for rank, idx in enumerate(top_indices):
                if idx in self.corpus_map:
                    item = self.corpus_map[idx]
                    keyword_hits[item['id']] = {'snippet': item['snippet'], 'rank': rank}

        fused_scores = {}
        k = 60
        for doc_id, hit in vector_hits.items():
            if doc_id not in fused_scores: fused_scores[doc_id] = 0
            fused_scores[doc_id] += 1 / (k + hit['rank'] + 1)
        for doc_id, hit in keyword_hits.items():
            if doc_id not in fused_scores: fused_scores[doc_id] = 0
            fused_scores[doc_id] += 1 / (k + hit['rank'] + 1)
            
        sorted_ids = sorted(fused_scores.keys(), key=lambda x: fused_scores[x], reverse=True)[:top_k]
        final_results = []
        for doc_id in sorted_ids:
            if doc_id in vector_hits: final_results.append({'id': doc_id, 'snippet': vector_hits[doc_id]['snippet']})
            elif doc_id in keyword_hits: final_results.append({'id': doc_id, 'snippet': keyword_hits[doc_id]['snippet']})
        return final_results

    def _rerank_evidence_with_cross_encoder(self, query: str, evidence: list[dict]) -> list[dict]:
        if not evidence: return []
        pairs = [(query, item['snippet']) for item in evidence]
        scores = self.cross_encoder.predict(pairs)
        for i, item in enumerate(evidence): 
            item['rerank_score'] = float(scores[i])
        return sorted(evidence, key=lambda x: x['rerank_score'], reverse=True)

    def _perform_holistic_extraction(self, knowledge_base: dict, event_name: str, variant_name: str):
        print(f"    - Pass 1: Holistic RAG extraction for '{variant_name}'...")
        all_fields_query = f"Extract all available information for the event '{event_name}', specifically for the '{variant_name}' category."
        candidate_evidence = self._retrieve_and_fuse_evidence(all_fields_query, top_k=RAG_CANDIDATE_POOL_SIZE)
        reranked_evidence = self._rerank_evidence_with_cross_encoder(all_fields_query, candidate_evidence)
        final_evidence = reranked_evidence[:RAG_FINAL_EVIDENCE_COUNT + 5]

        if not final_evidence:
            print("      - [WARNING] No relevant evidence found for holistic extraction.")
            return knowledge_base

        evidence_prompt = "\n".join([f"Evidence Snippet:\n---\n{e['snippet']}\n---" for e in final_evidence])
        fields_to_extract = [f"- {key}: {desc}" for key, desc in self.field_instructions.items()]
        fields_prompt = "\n".join(fields_to_extract)

        prompt = f"""You are an expert data analyst. Based on the evidence below, extract all specified fields for '{variant_name}' of '{event_name}'.
- Only use the provided evidence.
- If a value is missing, omit it.
- **IMPORTANT**: All dates MUST be in ISO 8601 format (YYYY-MM-DD).

## Evidence
{evidence_prompt}

## Task
Extract these fields into a JSON object:
{fields_prompt}

## Response
JSON object only. Example: {{"city": "Mumbai", "date": "2025-09-21"}}"""

        response_text = self._call_llm(prompt)
        try:
            match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if not match: return knowledge_base
            extracted_data = dirtyjson.loads(match.group(0))
            print(f"      - [SUCCESS] Holistic extracted {len(extracted_data)} fields.")
            confidence = 0.85
            for key, value in extracted_data.items():
                if key in self.schema and value:
                    if not knowledge_base[variant_name].get(key, Field()).value:
                        value_str = json.dumps(value) if isinstance(value, (dict, list)) else str(value)
                        knowledge_base[variant_name][key] = Field(value=value_str, confidence=confidence, inferred_by="rag_holistic", sources=final_evidence)
        except Exception: pass
        return knowledge_base

    def _perform_targeted_recovery(self, knowledge_base: dict, event_name: str, variant_name: str):
        print(f"    - Pass 2: Targeted Recovery for missing fields...")
        missing_fields = [k for k in self.schema if k not in DEFAULT_BLANK_FIELDS and not knowledge_base[variant_name].get(k, Field()).value]
        
        if not missing_fields: return knowledge_base
        
        for field in missing_fields:
            query = f"What is the {field} for {variant_name} in {event_name}?"
            evidence = self._retrieve_and_fuse_evidence(query, top_k=10)
            reranked = self._rerank_evidence_with_cross_encoder(query, evidence)[:3]
            
            if not reranked: continue

            evidence_text = "\n".join([e['snippet'] for e in reranked])
            prompt = f"""Based on the evidence, find the value for '{field}' for the race '{variant_name}'.
- **Dates MUST be in ISO 8601 format (YYYY-MM-DD).**
Evidence: {evidence_text}
Return a JSON object: {{"answer": "value"}} or {{"answer": null}} if not found."""
            
            response = self._call_llm(prompt)
            try:
                match = re.search(r'\{.*\}', response, re.DOTALL)
                if match:
                    res = dirtyjson.loads(match.group(0))
                    ans = res.get('answer')
                    if ans and str(ans).lower() not in ['null', 'none', 'unknown']:
                        knowledge_base[variant_name][field] = Field(value=str(ans), confidence=0.9, inferred_by="rag_targeted", sources=reranked)
                        if DEBUG: print(f"      - [RECOVERED] {field}: {ans}")
            except: pass
            
        return knowledge_base

    def _discover_and_validate_variants_from_content(self, content: str, knowledge_base: dict):
        print("    - Discovering all race variants from content...")
        prompt = f"""Identify all distinct race categories/distances (e.g., 10K, Half Marathon, Triathlon Sprint) in the text.
Return ONLY a JSON list of strings.
Text: {content[:10000]}..."""
        response_text = self._call_llm(prompt)
        try:
            match = re.search(r'\[.*\]', response_text, re.DOTALL)
            if match:
                variants = json.loads(match.group(0))
                if isinstance(variants, list):
                    cleaned_variants = [v for v in variants if isinstance(v, str) and len(v) < 100]
                    print(f"      - [SUCCESS] Found variants: {', '.join(cleaned_variants)}")
                    for variant_name in cleaned_variants:
                        if variant_name not in knowledge_base:
                            knowledge_base[variant_name] = {field: Field() for field in self.schema}
                    return
        except Exception:
            pass
        print("      - [WARNING] Variant discovery failed. Using default.")

    # UPDATED: Accepts custom confidence
    def _inject_pre_filled_data(self, knowledge_base: dict, pre_filled_data: dict, pre_filled_confidence: float = 0.3):
        if not pre_filled_data: return
        print(f"    - Injecting pre-filled data (confidence={pre_filled_confidence})...")
        for variant_name in knowledge_base.keys():
            for key, value in pre_filled_data.items():
                if key in self.schema and value:
                    # Apply logic: update if new confidence is higher
                    if knowledge_base[variant_name].get(key, Field()).confidence < pre_filled_confidence:
                        knowledge_base[variant_name][key] = Field(value=str(value), confidence=pre_filled_confidence, inferred_by="pre_processed_data")

    def _run_inferential_filling(self, knowledge_base: dict):
        print("\n[INFERENCE] Running final analysis to infer missing data...")
        for variant, data in knowledge_base.items():
            city = data.get('city', Field()).value
            country = data.get('country', Field()).value
            if city and not country:
                resp = self._call_llm(f"What country is {city} in? Return ONLY the country name.")
                if resp:
                    knowledge_base[variant]['country'] = Field(value=resp.strip(), confidence=0.8, inferred_by="inference")
        return knowledge_base

    def determine_event_type(self, url: str) -> str | None:
        print(f"  - Determining event type for URL: {url}")
        content = self._get_content_from_url(url)
        if not content: return None
        valid_types = ", ".join(CHOICE_OPTIONS["type"])
        prompt = f"Analyze the text and determine the athletic event type. Answer MUST be one of: {valid_types}.\nText: {content[:2000]}"
        response = self._call_llm(prompt)
        if not response: return None
        for et in CHOICE_OPTIONS["type"]:
            if et.lower() in response.lower():
                print(f"    - [SUCCESS] Determined type: {et}")
                return et
        return None

    def _check_supabase_for_cache(self, event_key: str, legacy_key: str = None) -> dict | None:
        if not SUPABASE_CONFIGURED: return None
        
        data = get_knowledge_cache(event_key)
        if data:
            print(f"[SUCCESS] Found cache for '{event_key}' in Supabase.")
            return data
            
        if legacy_key and legacy_key != event_key:
            print(f"  - Primary key missing. Checking legacy key: '{legacy_key}'...")
            data = get_knowledge_cache(legacy_key)
            if data:
                print(f"[SUCCESS] Found legacy cache for '{legacy_key}' in Supabase.")
                return data
        return None

    def run(self, race_info: dict) -> dict | None:
        event_name = race_info.get("Festival")
        event_key = self.get_caching_key(event_name)
        legacy_key = self.get_legacy_caching_key(event_name)
        
        cached_data = self._check_supabase_for_cache(event_key, legacy_key)
        if cached_data:
            return {v: {f: Field.from_dict(d) for f, d in fs.items()} for v, fs in cached_data.items()}
        
        search_results = self._step_1a_initial_search(race_info)
        if not search_results: return None
        validated_urls = self._step_1b_validate_and_select_urls(event_name, search_results)
        if not validated_urls: return None
        
        # Uses default confidence of 0.3
        knowledge_base = self._crawl_and_extract(validated_urls, race_info)
        
        if knowledge_base and SUPABASE_CONFIGURED:
            serializable_kb = {v: {f: field.to_dict() for f, field in fs.items()} for v, fs in knowledge_base.items()}
            set_knowledge_cache(event_key, serializable_kb)
        return knowledge_base

    def run_direct(self, race_info: dict, direct_urls: list, pre_filled_data: dict = None, pre_filled_confidence: float = 0.3) -> dict | None:
        event_name = race_info.get("Festival")
        url_part = hashlib.md5(direct_urls[0].encode()).hexdigest()[:8]
        event_key = self.get_caching_key(f"{event_name}-{url_part}")
        legacy_key = self.get_legacy_caching_key(event_name)
        
        cached_data = self._check_supabase_for_cache(event_key, legacy_key)
        if cached_data:
            return {v: {f: Field.from_dict(d) for f, d in fs.items()} for v, fs in cached_data.items()}

        validated_urls = [url for url in direct_urls if self._is_valid_url(url)]
        if not validated_urls: return None
        
        knowledge_base = self._crawl_and_extract(validated_urls, race_info, pre_filled_data, pre_filled_confidence)
        
        if knowledge_base and SUPABASE_CONFIGURED:
            serializable_kb = {v: {f: field.to_dict() for f, field in fs.items()} for v, fs in knowledge_base.items()}
            set_knowledge_cache(event_key, serializable_kb)
        return knowledge_base

    def _is_valid_url(self, url: str) -> bool:
        if not url or not url.startswith(('http://', 'https://')): return False
        if any(year in url for year in self.invalid_years): return False
        return True

    def _crawl_and_extract(self, urls: list, race_info: dict, pre_filled_data: dict = None, pre_filled_confidence: float = 0.3) -> dict:
        event_name = race_info.get("Festival")
        event_id_str = self.get_caching_key(event_name)
        self.chroma_collection = self.chroma_client.get_or_create_collection(name=f"coll_{event_id_str}")
        print(f"\n[STEP 2] Starting RAG processing for '{event_name}' (Collection: coll_{event_id_str})")
        
        self.mission_corpus = []
        self.corpus_map = {}
        self.bm25_index = None

        knowledge_base = {}
        all_content = []
        with ThreadPoolExecutor(max_workers=MAX_CONCURRENT_CRAWLERS) as executor:
            futures = {executor.submit(self._get_content_from_url, url): url for url in urls}
            for future in as_completed(futures):
                if content := future.result():
                    all_content.append(content)
                    self._chunk_and_index_text(content, futures[future], event_id_str)

        if not all_content:
            print("  - [WARNING] No content crawled.")
            return {}

        self._build_bm25_index()

        combined_content = "\n\n".join(all_content)
        self._discover_and_validate_variants_from_content(combined_content, knowledge_base)

        if not knowledge_base:
            knowledge_base[event_name] = {field: Field() for field in self.schema}

        if pre_filled_data:
            self._inject_pre_filled_data(knowledge_base, pre_filled_data, pre_filled_confidence)

        for variant in list(knowledge_base.keys()):
            self._perform_holistic_extraction(knowledge_base, event_name, variant)
            self._perform_targeted_recovery(knowledge_base, event_name, variant)

        self._run_inferential_filling(knowledge_base)
        print("\n[SUCCESS] Extraction complete.")
        return knowledge_base