# supabase_client.py

import json
import time
from supabase import create_client, Client
from functools import wraps

from config import SUPABASE_URL, SUPABASE_KEY, SUPABASE_SERVICE_ROLE_KEY

# Global client - initialized to None. This will hold our singleton instance.
supabase: Client = None

def get_supabase_client() -> Client | None:
    """Singleton accessor for the Supabase client."""
    global supabase
    if supabase is None:
        init_supabase_client()
    return supabase

def init_supabase_client():
    global supabase
    if not all([SUPABASE_URL, SUPABASE_KEY, SUPABASE_SERVICE_ROLE_KEY]):
        print("[ERROR] Supabase credentials are not configured. Check your .env file.")
        supabase = None
        return

    try:
        # print("[INFO] Initializing Supabase client...") # Reduce noise
        supabase = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
        # print("  - [SUCCESS] Supabase client initialized.")
    except Exception as e:
        print(f"[ERROR] Failed to connect to Supabase: {e}")
        supabase = None

# --- Decorator for resilience ---
def supabase_operation(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        client = get_supabase_client()
        if not client:
            error_message = "Supabase client not initialized."
            if "delete" in func.__name__: return False, error_message
            elif "list" in func.__name__: return []
            return None
        
        for attempt in range(3):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # IMPORTANT: Don't retry on 404 (Bucket not found) errors!
                if "Bucket not found" in str(e) or "Object not found" in str(e):
                    # Fail gracefully without noise
                    return None
                
                print(f"[WARNING] Supabase operation '{func.__name__}' failed on attempt {attempt + 1}: {e}")
                if attempt < 2:
                    time.sleep(2 ** attempt)
        
        return None # Return None on persistent failure
    return wrapper

# --- Client Functions ---

@supabase_operation
def get_knowledge_cache(event_key: str) -> dict | None:
    client = get_supabase_client()
    response = client.table('knowledge_cache').select('data').eq('event_key', event_key).limit(1).execute()
    if response.data:
        data = response.data[0].get('data')
        if isinstance(data, str):
            try: return json.loads(data)
            except json.JSONDecodeError: return None
        return data
    return None

@supabase_operation
def set_knowledge_cache(event_key: str, data: dict):
    client = get_supabase_client()
    client.table('knowledge_cache').upsert({'event_key': event_key, 'data': data}).execute()
    print(f"  - [SUCCESS] Supabase: Knowledge cache saved for '{event_key}'.")

@supabase_operation
def download_from_storage(file_path: str) -> str | None:
    client = get_supabase_client()
    # Explicitly try/except here to catch the 404 before the decorator if needed, 
    # but the decorator logic covers it.
    response = client.storage.from_('crawl_cache').download(file_path)
    return response.decode('utf-8') if response else None

@supabase_operation
def upload_to_storage(file_path: str, content: str):
    client = get_supabase_client()
    try:
        client.storage.from_('crawl_cache').upload(file_path, content.encode('utf-8'), {"upsert": True})
    except Exception as e:
        # Swallow bucket errors to avoid log noise if user hasn't set it up
        if "Bucket not found" not in str(e):
             print(f"  - [WARNING] Supabase upload failed: {e}")