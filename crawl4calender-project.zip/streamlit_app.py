# streamlit_app.py
# This is the main entry point for the Crawl4Calender Agent System UI using Streamlit.

import streamlit as st
import os
import sys
import shutil
import tempfile
import threading
import time
import traceback
import queue
from datetime import datetime
from dotenv import load_dotenv

# --- Project Imports ---
from config import CRAWL_CACHE_DIR, KNOWLEDGE_CACHE_DIR, OUTPUT_DIR, APP_VERSION, VECTOR_DB_PATH, SPACY_MODEL
from main import run_calendar_mode, run_default_websites_mode
from agent import AgentInitializationError

# --- Constants ---
LOGS_DIR = "streamlit_logs"

# --- Load Environment Variables ---
ENV_FOUND = load_dotenv(override=True)
MISTRAL_API_KEY = os.getenv("MISTRAL_API_KEY")
SEARCH_API_KEY = os.getenv("SEARCH_API_KEY")
CSE_ID = os.getenv("CSE_ID")
NGROK_AUTH_TOKEN = os.getenv("NGROK_AUTH_TOKEN")

# --- A single, global queue for thread-safe communication ---
COMMUNICATION_QUEUE = queue.Queue()


# --- Prerequisite Checks ---
@st.cache_data
def check_spacy_model():
    """Checks if the required spaCy model is installed. Cached for performance."""
    try:
        import spacy
        spacy.load(SPACY_MODEL)
        return True
    except (ImportError, OSError):
        return False


SPACY_MODEL_AVAILABLE = check_spacy_model()


# --- Ngrok Integration ---
def setup_ngrok():
    """Sets up ngrok if the auth token is available."""
    if NGROK_AUTH_TOKEN:
        try:
            from pyngrok import ngrok
            ngrok.set_auth_token(NGROK_AUTH_TOKEN)
            public_url = ngrok.connect(8501)
            sys.__stdout__.write("=" * 60 + "\n")
            sys.__stdout__.write(f"✅ Streamlit App is live on the web!\n")
            sys.__stdout__.write(f"🔗 Public URL: {public_url}\n")
            sys.__stdout__.write("=" * 60 + "\n")
        except Exception as e:
            sys.__stdout__.write(f"❌ Failed to start ngrok: {e}\n")


# --- State & Session Management ---
def initialize_session_state():
    """Initializes variables in the session state."""
    if 'processing' not in st.session_state:
        st.session_state.processing = False
    if 'log_content' not in st.session_state:
        st.session_state.log_content = ""
    if 'progress' not in st.session_state:
        st.session_state.progress = (0, 0)
    if 'stop_event' not in st.session_state:
        st.session_state.stop_event = threading.Event()
    if 'worker_thread' not in st.session_state:
        st.session_state.worker_thread = None
    if 'log_file_path' not in st.session_state:
        st.session_state.log_file_path = None
    if 'output_files' not in st.session_state:
        st.session_state.output_files = []
    if 'processing_error' not in st.session_state:
        st.session_state.processing_error = None


# --- Log Redirection & Callbacks ---
def thread_safe_progress_callback(processed, total):
    """Puts a progress update into the communication queue."""
    COMMUNICATION_QUEUE.put({'type': 'progress', 'data': (processed, total)})


class QueueLogStream:
    """A thread-safe stream that redirects stdout/stderr to the communication queue."""

    def __init__(self):
        self.line_buffer = ""

    def write(self, text):
        self.line_buffer += text
        if '\n' in self.line_buffer:
            lines = self.line_buffer.split('\n')
            for line in lines[:-1]:
                COMMUNICATION_QUEUE.put({'type': 'log', 'data': line + '\n'})
            self.line_buffer = lines[-1]

    def flush(self):
        if self.line_buffer:
            COMMUNICATION_QUEUE.put({'type': 'log', 'data': self.line_buffer + '\n'})
            self.line_buffer = ""


# --- UI Screen ---
def show_main_screen():
    st.title("🗓️ Crawl4Calender")
    st.markdown(f"**Version:** `{APP_VERSION}`")
    st.write("---")

    if not SPACY_MODEL_AVAILABLE:
        st.error(f"**Prerequisite Missing:** The spaCy model '{SPACY_MODEL}' was not found. "
                 f"Please run `python -m spacy download {SPACY_MODEL}` in your terminal to install it.", icon="🚨")

    col1, col2 = st.columns([0.45, 0.55], gap="large")
    with col1:
        st.header("Configuration")
        with st.container(border=True):
            st.subheader("1. Select Mode")
            mode = st.selectbox("Mode", ["Default Websites", "Crawl Cycling Calendar"],
                                disabled=st.session_state.processing, label_visibility="collapsed")
            input_files = []
            if mode == "Default Websites":
                st.info("Select one or more pre-scraped JSON files.")
                uploaded_files = st.file_uploader("Upload JSON file(s)", type="json", accept_multiple_files=True,
                                                  disabled=st.session_state.processing)
                if uploaded_files:
                    temp_dir = tempfile.mkdtemp()
                    for uploaded_file in uploaded_files:
                        path = os.path.join(temp_dir, uploaded_file.name)
                        with open(path, "wb") as f: f.write(uploaded_file.getvalue())
                        input_files.append(path)
                    st.caption(f"{len(input_files)} file(s) ready for processing.")
            elif mode == "Crawl Cycling Calendar":
                st.info("This mode automatically crawls `audaxindia.in` for the latest cycling events.")
        with st.container(border=True):
            st.subheader("2. Configure Run")
            output_dir = st.text_input("Output Directory (optional)", placeholder=f"Default: ./{OUTPUT_DIR}",
                                       disabled=st.session_state.processing,
                                       help="Specify a folder for output files. Defaults to 'outputs'.")
            output_dir = output_dir or OUTPUT_DIR
            max_events_str = st.text_input("Max events to process (optional)",
                                           disabled=st.session_state.processing,
                                           help="Limit the number of events to process.")
            max_events = int(max_events_str) if max_events_str and max_events_str.isdigit() else None
        with st.container(border=True):
            st.subheader("3. Controls")
            api_keys_missing = not all([MISTRAL_API_KEY, SEARCH_API_KEY, CSE_ID])
            if api_keys_missing:
                st.error("API keys are missing. Check your .env file.", icon="🚨")
            start_button_disabled = (st.session_state.processing or api_keys_missing
                                     or not SPACY_MODEL_AVAILABLE
                                     or (mode == "Default Websites" and not input_files))
            if st.button("▶️ Start Processing", type="primary", use_container_width=True,
                         disabled=start_button_disabled):
                start_processing(mode, input_files, output_dir, max_events)
            if st.button("⏹️ Stop Process", use_container_width=True, disabled=not st.session_state.processing):
                st.session_state.stop_event.set()
                st.toast("Stop signal sent to agent...")
            if st.button("🗑️ Clear All Caches", use_container_width=True, disabled=st.session_state.processing):
                clear_all_caches()
    with col2:
        st.header("Live Log")
        log_placeholder = st.empty()
        st.header("Progress")
        progress_placeholder = st.empty()

        # --- BUG FIX ---
        # Only declare the text_area widget ONCE per script run.
        # Its content will be updated dynamically via the `update_ui_while_processing` loop.
        log_placeholder.text_area("Logs", value=st.session_state.log_content, height=300, disabled=True,
                                  label_visibility="collapsed", key="log_display_area")

        if st.session_state.processing_error:
            st.error("An error occurred during processing. See the log for details.", icon="🔥")
        if not st.session_state.processing and st.session_state.output_files:
            st.header("Download Results")
            with st.container(border=True):
                for filename in st.session_state.output_files:
                    file_path = os.path.join(st.session_state.get('run_output_dir', OUTPUT_DIR), filename)
                    if os.path.exists(file_path):
                        with open(file_path, "rb") as fp:
                            st.download_button(f"📄 Download {filename}", fp, filename, "text/csv",
                                               use_container_width=True, key=f"dl_{filename}")

    if st.session_state.processing:
        update_ui_while_processing(progress_placeholder)
    else:
        display_progress(progress_placeholder)


# --- Backend Logic ---
def run_process_wrapper(target_func, log_file, **kwargs):
    """Wrapper to run the target function and handle logging/errors within a thread."""
    sys.stdout = QueueLogStream()
    sys.stderr = sys.stdout
    try:
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"--- Process started at {datetime.now()} ---\n")
        target_func(**kwargs)
    except Exception:
        error_message = f"A critical error occurred in the background process:\n\n{traceback.format_exc()}"
        COMMUNICATION_QUEUE.put({'type': 'error', 'data': error_message})
    finally:
        sys.stdout.flush()
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(f"\n--- Process finished at {datetime.now()} ---\n")


def start_processing(mode, input_files, output_dir, max_events):
    st.session_state.processing = True
    st.session_state.log_content = "--- Starting new process... ---\n"
    st.session_state.progress = (0, 0)
    st.session_state.stop_event.clear()
    st.session_state.output_files = []
    st.session_state.processing_error = None
    while not COMMUNICATION_QUEUE.empty(): COMMUNICATION_QUEUE.get()

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    st.session_state.log_file_path = os.path.join(LOGS_DIR, f"log_{timestamp}.txt")
    st.session_state.run_output_dir = output_dir
    os.makedirs(output_dir, exist_ok=True)
    st.session_state.files_before_run = set(os.listdir(output_dir))

    target, args = None, {}
    if mode == "Default Websites":
        target = run_default_websites_mode
        args = {"input_files": input_files, "output_dir_override": output_dir, "max_events": max_events,
                "counter_callback": thread_safe_progress_callback, "stop_event": st.session_state.stop_event}
    else:  # Calendar Mode
        target = run_calendar_mode
        args = {"output_dir_override": output_dir, "max_events": max_events,
                "counter_callback": thread_safe_progress_callback, "stop_event": st.session_state.stop_event}

    wrapper_args = {'target_func': target, 'log_file': st.session_state.log_file_path, **args}
    st.session_state.worker_thread = threading.Thread(target=run_process_wrapper, kwargs=wrapper_args)
    st.session_state.worker_thread.start()
    st.rerun()


def update_ui_from_queue():
    """Drains the communication queue and updates the session state."""
    while not COMMUNICATION_QUEUE.empty():
        try:
            msg = COMMUNICATION_QUEUE.get_nowait()
            msg_type = msg.get('type')
            if msg_type == 'log':
                log_data = msg['data']
                st.session_state.log_content += log_data
                if st.session_state.log_file_path:
                    with open(st.session_state.log_file_path, 'a', encoding='utf-8') as f:
                        f.write(log_data)
            elif msg_type == 'progress':
                st.session_state.progress = msg['data']
            elif msg_type == 'error':
                error_data = msg['data']
                st.session_state.processing_error = error_data
                st.session_state.log_content += error_data
        except queue.Empty:
            break


def update_ui_while_processing(progress_placeholder):
    """Continuously updates the UI by draining the queue and checking thread status."""
    if not st.session_state.worker_thread.is_alive():
        # Final update and stop
        update_ui_from_queue()
        st.session_state.processing = False
        run_output_dir = st.session_state.get('run_output_dir', OUTPUT_DIR)
        if os.path.exists(run_output_dir):
            files_after_run = set(os.listdir(run_output_dir))
            st.session_state.output_files = sorted(list(files_after_run - st.session_state.files_before_run))
        if st.session_state.stop_event.is_set():
            st.toast("Processing was stopped by the user.")
        elif st.session_state.processing_error:
            st.toast("Processing failed with an error.", icon="❌")
        else:
            st.toast("Processing finished successfully!", icon="✅")
        time.sleep(0.5)
        st.rerun()
    else:
        # Live update
        update_ui_from_queue()
        display_progress(progress_placeholder)
        time.sleep(0.1)  # Fast refresh for responsiveness
        st.rerun()


def clear_all_caches():
    st.toast("Clearing all caches...")
    st.session_state.log_content += "\n--- Clearing All Caches ---\n"
    for d, n in [(CRAWL_CACHE_DIR, "Crawl"), (KNOWLEDGE_CACHE_DIR, "Knowledge"), (VECTOR_DB_PATH, "Vector Database")]:
        try:
            if os.path.exists(d): shutil.rmtree(d)
            os.makedirs(d, exist_ok=True)
            st.session_state.log_content += f"✅ Success: Cleared '{n}' cache.\n"
        except Exception as e:
            st.session_state.log_content += f"❌ Error clearing {n}: {e}\n"
    st.session_state.log_content += "--- All Caches Cleared ---\n"


def display_progress(placeholder):
    processed, total = st.session_state.progress
    with placeholder.container():
        if total > 0:
            st.progress(processed / total if total > 0 else 0)
            st.write(f"**Events Processed: {processed} / {total}**")
        elif st.session_state.processing:
            st.write("Initializing...")
        else:
            st.write("Awaiting process start.")


def main():
    st.set_page_config(page_title="Crawl4Calender", layout="wide", initial_sidebar_state="collapsed")
    initialize_session_state()
    if 'env_notified' not in st.session_state:
        if ENV_FOUND:
            st.toast("✅ Successfully loaded credentials from .env file.", icon="👍")
        elif not all([MISTRAL_API_KEY, SEARCH_API_KEY, CSE_ID]):
            st.warning("⚠️ Could not find a .env file. API keys may be missing.", icon="❗")
        st.session_state.env_notified = True
    show_main_screen()


if __name__ == '__main__':
    os.makedirs(CRAWL_CACHE_DIR, exist_ok=True)
    os.makedirs(KNOWLEDGE_CACHE_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(LOGS_DIR, exist_ok=True)
    setup_ngrok()
    main()