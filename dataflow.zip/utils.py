# utils.py

import os
import re
import csv
import json
import ftfy
from datetime import datetime
from dateutil.parser import parse as date_parse

from schemas import DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS
from config import MIN_CONFIDENCE_THRESHOLD
from agent import Field

def serialize_knowledge_base(knowledge_base: dict) -> dict:
    serializable_kb = {}
    for variant, data in knowledge_base.items():
        serializable_kb[variant] = {field_name: field_obj.to_dict() for field_name, field_obj in data.items()}
    return serializable_kb

def deserialize_knowledge_base(cached_data: dict) -> dict:
    knowledge_base = {}
    for variant, data in cached_data.items():
        knowledge_base[variant] = {
            field_name: Field.from_dict(field_data) for field_name, field_data in data.items()
        }
    return knowledge_base

def format_final_row(festival_name_input: str, variant_name: str, data: dict, schema: list) -> dict | None:
    
    def normalize_complex_value(val):
        """Recursively extracts the primary value from nested dictionaries/lists."""
        if isinstance(val, str):
            # Try parsing strings that look like JSON
            if val.strip().startswith('{') and val.strip().endswith('}'):
                try:
                    val = json.loads(val)
                except json.JSONDecodeError:
                    return val
            else:
                return val
        
        if isinstance(val, dict):
            # Prioritize specific keys
            for key in ['amount', 'value', 'price', 'final', 'standard']:
                if key in val:
                    return normalize_complex_value(val[key])
            # If no priority key, grab the first numeric value found
            for v in val.values():
                if isinstance(v, (int, float)) or (isinstance(v, str) and v.replace('.', '', 1).isdigit()):
                    return normalize_complex_value(v)
            # Fallback: grab the first value
            return normalize_complex_value(list(val.values())[0]) if val else ""
            
        if isinstance(val, list):
            # If list, grab the first non-empty item
            for item in val:
                extracted = normalize_complex_value(item)
                if extracted: return extracted
            return ""
            
        return str(val) if val is not None else ""

    def get_value(field_name: str) -> any:
        field_obj = data.get(field_name)
        if not isinstance(field_obj, Field): return ""
        min_thresh = 0.4 if "inference" in field_obj.inferred_by else MIN_CONFIDENCE_THRESHOLD
        if field_obj.confidence >= min_thresh:
            return field_obj.value
        return ""

    def finalize_value(value: any) -> str:
        # Step 1: Flatten complex JSON structures
        value = normalize_complex_value(value)
        
        # Step 2: Clean string
        text = ftfy.fix_text(str(value)).strip()
        if text.lower() in ["na", "n/a", "", "none", "not specified", "null", "unknown"]: return ""
        return text

    row = {}
    for key in schema:
        if key in DEFAULT_BLANK_FIELDS:
            row[key] = ""
            continue
        
        raw_value = finalize_value(get_value(key))
        
        if key == "city":
            row[key] = raw_value.split(',')[0].strip()
        elif key == "registrationCost":
             # Remove currency symbols and commas
             row[key] = re.sub(r'[^\d.]', '', raw_value)
        elif key in ["runningDistance", "cyclingDistance", "swimDistance"]:
             # Extract just the number if unit is attached (e.g. "42.2 km" -> "42.2")
             match = re.search(r'(\d+\.?\d*)', raw_value)
             row[key] = match.group(1) if match else raw_value
        elif key in ["date", "lastDate"]:
            if re.match(r"\d{4}-\d{2}-\d{2}", raw_value):
                row[key] = datetime.strptime(raw_value, "%Y-%m-%d").strftime("%d/%m/%Y")
            else:
                try:
                    dt = date_parse(raw_value, fuzzy=True, dayfirst=True)
                    if dt.year >= 2024:
                        row[key] = dt.strftime("%d/%m/%Y")
                    else:
                        row[key] = raw_value
                except (ValueError, TypeError):
                    row[key] = raw_value
        else:
            row[key] = raw_value

    if festival_name_input and festival_name_input.lower() not in variant_name.lower():
        row["event"] = f"{festival_name_input} - {variant_name}"
    else:
        row["event"] = variant_name

    if not row.get("organiser") and festival_name_input:
        row["organiser"] = festival_name_input

    if row.get("date"):
        try:
            dt = date_parse(row["date"], dayfirst=True)
            row["month"] = dt.strftime("%B")
            row["editionYear"] = str(dt.year)
        except: pass

    if not row.get("approvalStatus"): row["approvalStatus"] = "Approved"

    return row