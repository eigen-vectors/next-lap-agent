# utils.py

import os
import re
import csv
import json
import ftfy
from dateutil.parser import parse as date_parse

from schemas import DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS
from config import MIN_CONFIDENCE_THRESHOLD
from agent import Field


def serialize_knowledge_base(knowledge_base: dict) -> dict:
    serializable_kb = {}
    for variant, data in knowledge_base.items():
        serializable_kb[variant] = {field_name: field_obj.to_dict() for field_name, field_obj in data.items()}
    return serializable_kb


def deserialize_knowledge_base(cached_data: dict) -> dict:
    knowledge_base = {}
    for variant, data in cached_data.items():
        knowledge_base[variant] = {
            field_name: Field(
                value=field_data.get('value'),
                confidence=field_data.get('confidence', 0.0),
                sources=field_data.get('sources', []),
                inferred_by=field_data.get('inferred_by', '')
            ) for field_name, field_data in data.items()
        }
    return knowledge_base


def format_final_row(festival_name_input: str, variant_name: str, data: dict, schema: list) -> dict | None:
    def get_value(field_name: str) -> any:
        field_obj = data.get(field_name)
        if not isinstance(field_obj, Field): return ""
        min_thresh = 0.45 if "inference" in field_obj.inferred_by else MIN_CONFIDENCE_THRESHOLD
        if field_obj.confidence >= min_thresh:
            return field_obj.value
        return ""

    def finalize_value(value: any) -> str:
        if value is None: return ""
        text = ftfy.fix_text(str(value)).strip()
        if text.lower() in ["na", "n/a", "", "none", "not specified", "null", "true", "false"]: return ""
        return text

    row = {}
    for key in schema:
        if key in DEFAULT_BLANK_FIELDS:
            row[key] = ""
            continue

        raw_value = finalize_value(get_value(key))
        cleaned_value = raw_value

        if key == "city":
            row[key] = cleaned_value.split(',')[0].strip()
        elif key in CHOICE_OPTIONS:
            found = False
            for option in CHOICE_OPTIONS[key]:
                if re.search(r'\b' + re.escape(option) + r'\b', cleaned_value, re.IGNORECASE):
                    row[key] = option
                    found = True
                    break
            if not found: row[key] = ""
        elif key in ["date", "lastDate"]:
            try:
                dt = date_parse(cleaned_value, fuzzy=True, dayfirst=True)
                if dt.year >= 2024:
                    row[key] = dt.strftime("%d/%m/%Y")
                else:
                    row[key] = ""
            except (ValueError, TypeError):
                row[key] = ""
        else:
            row[key] = cleaned_value

    if festival_name_input and festival_name_input.lower() not in variant_name.lower():
        row["event"] = f"{festival_name_input} - {variant_name}"
    else:
        row["event"] = variant_name

    if not row.get("organiser") and festival_name_input:
        row["organiser"] = festival_name_input

    if row.get("date"):
        try:
            dt = date_parse(row["date"], dayfirst=True)
            row["month"] = dt.strftime("%B")
            year_str = str(dt.year)
            row["editionYear"], row["lastEdition"] = year_str, year_str
            first_ed_str = str(row.get("firstEdition", ""))
            if first_ed_str and first_ed_str.isdigit():
                count = int(year_str) - int(first_ed_str) + 1
                row["countEditions"] = str(count) if count > 0 else "1"
            else:
                row["countEditions"] = "1"
        except (ValueError, TypeError):
            pass

    if not row.get("restrictedTraffic"): row["restrictedTraffic"] = "Yes"
    if not row.get("aidStations"): row["aidStations"] = "Yes"
    if not row.get("approvalStatus"): row["approvalStatus"] = "Approved"

    return row