# main.py
# This is the main entry point for running the Crawl4AI Mistral Analyst Agent.

import os
import re
import csv
import json
from datetime import datetime
from urllib.parse import urljoin
from collections import OrderedDict

from agent import MistralAnalystAgent, Field
from config import (
    MISTRAL_API_KEY, SEARCH_API_KEY, CSE_ID,
    OUTPUT_DIR, VECTOR_DB_PATH,
    CRAWL_CACHE_DIR, KNOWLEDGE_CACHE_DIR, MIN_CONFIDENCE_THRESHOLD
)
from schemas import (
    TRIATHLON_SCHEMA, RUNNING_SCHEMA, SWIMMING_SCHEMA, DUATHLON_SCHEMA,
    AQUATHLON_SCHEMA, AQUABIKE_SCHEMA, CYCLING_SCHEMA, FITNESS_RACING_SCHEMA,
    DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS
)

APP_VERSION = "v95.0-Robust-IO"


def serialize_knowledge_base(knowledge_base: dict) -> dict:
    serializable_kb = {}
    for variant, data in knowledge_base.items():
        serializable_kb[variant] = {field_name: field_obj.to_dict() for field_name, field_obj in data.items()}
    return serializable_kb


def deserialize_knowledge_base(cached_data: dict) -> dict:
    knowledge_base = {}
    for variant, data in cached_data.items():
        knowledge_base[variant] = {
            field_name: Field(
                value=field_data.get('value'),
                confidence=field_data.get('confidence', 0.0),
                sources=field_data.get('sources', []),
                inferred_by=field_data.get('inferred_by', '')
            ) for field_name, field_data in data.items()
        }
    return knowledge_base


def format_final_row(festival_name_input: str, variant_name: str, data: dict, schema: list) -> dict | None:
    from dateutil.parser import parse as date_parse
    import ftfy

    def get_value(field_name: str) -> any:
        field_obj = data.get(field_name)
        if not isinstance(field_obj, Field): return ""
        min_thresh = 0.45 if "inference" in field_obj.inferred_by else MIN_CONFIDENCE_THRESHOLD
        if field_obj.confidence >= min_thresh:
            return field_obj.value
        return ""

    def finalize_value(value: any) -> str:
        if value is None: return ""
        text = ftfy.fix_text(str(value)).strip()
        if text.lower() in ["na", "n/a", "", "none", "not specified", "null", "true", "false"]: return ""
        return text

    def find_final_price(data_struct):
        if isinstance(data_struct, dict):
            for key in ['final', 'standard', 'price']:
                if key in data_struct:
                    value = data_struct[key]
                    if isinstance(value, (int, float)): return value
                    if isinstance(value, str):
                        numeric_val = re.search(r'\d+', value)
                        if numeric_val: return int(numeric_val.group(0))
                    if isinstance(value, dict): return find_final_price(value)

            last_numeric_val = None
            for key, value in data_struct.items():
                result = find_final_price(value)
                if result is not None: last_numeric_val = result
            return last_numeric_val

        if isinstance(data_struct, list):
            last_numeric_val = None
            for item in data_struct:
                result = find_final_price(item)
                if result is not None: last_numeric_val = result
            return last_numeric_val
        return None

    row = {}
    for key in schema:
        if key in DEFAULT_BLANK_FIELDS:
            row[key] = ""
            continue

        raw_value = finalize_value(get_value(key))

        try:
            if raw_value and raw_value.startswith('{') and raw_value.endswith('}'):
                parsed_json = json.loads(raw_value)
                if isinstance(parsed_json, dict):
                    if key == 'registrationCost':
                        price = find_final_price(parsed_json)
                        raw_value = str(price) if price is not None else raw_value
                    elif key == 'organiser':
                        raw_value = parsed_json.get('name', raw_value)
                    elif key == 'firstEdition':
                        raw_value = parsed_json.get('year', raw_value)
                    elif key == 'lastDate':
                        raw_value = parsed_json.get('registrationCloses',
                                                    parsed_json.get('closes', parsed_json.get('endDate', raw_value)))
                    elif key == 'ageLimitation':
                        age_limits = {k: v for k, v in parsed_json.items() if v}
                        if age_limits: raw_value = list(age_limits.values())[0]
        except (json.JSONDecodeError, TypeError):
            pass

        cleaned_value = finalize_value(raw_value)
        if key == "city":
            row[key] = cleaned_value.split(',')[0].strip()
        elif key in CHOICE_OPTIONS:
            found = False
            for option in CHOICE_OPTIONS[key]:
                if re.search(r'\b' + re.escape(option) + r'\b', cleaned_value, re.IGNORECASE):
                    row[key] = option
                    found = True
                    break
            if not found: row[key] = ""
        elif key == "participationType":
            row[key] = re.sub(r"[\[\]\'\"]", "", cleaned_value).replace(",", ", ")
        elif key == "aidStations":
            row[key] = "Yes" if cleaned_value.startswith('[') and len(cleaned_value) > 2 else cleaned_value
        elif key in ["runningDistance", "cyclingDistance"]:
            match = re.search(r'(\d+\.?\d*)', cleaned_value)
            if match:
                val = float(match.group(1))
                row[key] = "" if val > 1900 else str(val)
            else:
                row[key] = ""
        elif key in ["date", "lastDate"]:
            try:
                dt = date_parse(cleaned_value, fuzzy=True, dayfirst=True)
                if dt.year >= 2024:
                    row[key] = dt.strftime("%d/%m/%Y")
                else:
                    row[key] = ""
            except (ValueError, TypeError):
                row[key] = ""
        elif key == "startTime":
            try:
                row[key] = date_parse(cleaned_value, fuzzy=True).strftime("%I:%M %p")
            except (ValueError, TypeError):
                row[key] = ""
        else:
            row[key] = cleaned_value

    if str(variant_name).startswith('http'):
        row["event"] = festival_name_input
    elif festival_name_input and festival_name_input.lower() not in variant_name.lower():
        row["event"] = f"{festival_name_input} - {variant_name}"
    else:
        row["event"] = variant_name

    if not row.get("organiser") and festival_name_input:
        row["organiser"] = festival_name_input

    if row.get("date"):
        try:
            dt = date_parse(row["date"], dayfirst=True)
            row["month"] = dt.strftime("%B")
            year_str = str(dt.year)
            row["editionYear"], row["lastEdition"] = year_str, year_str
            first_ed_str = str(row.get("firstEdition", ""))
            if first_ed_str and first_ed_str.isdigit():
                count = int(year_str) - int(first_ed_str) + 1
                row["countEditions"] = str(count) if count > 0 else "1"
            else:
                row["countEditions"] = "1"
        except (ValueError, TypeError):
            pass

    if not row.get("restrictedTraffic"): row["restrictedTraffic"] = "Yes"
    if not row.get("aidStations"): row["aidStations"] = "Yes"
    if not row.get("approvalStatus"): row["approvalStatus"] = "Approved"

    for key in DEFAULT_BLANK_FIELDS:
        if key in row: row[key] = ""

    return row


def run_calendar_mode(output_dir_override=None, max_events=None, counter_callback=None, stop_event=None):
    agent_for_crawling = main_agent = None
    failed_missions = []

    print("=" * 60)
    print(f"🚀 LAUNCHING Crawl4AI Agent {APP_VERSION} in Calendar Crawl Mode...")
    print("=" * 60)

    try:
        CALENDAR_URL = "https://www.audaxindia.in/events.php"
        EVENT_TYPE = "Cycling"
        effective_output_dir = output_dir_override if output_dir_override else OUTPUT_DIR
        agent_for_crawling = MistralAnalystAgent(mistral_key=MISTRAL_API_KEY, search_key=SEARCH_API_KEY, cse_id=CSE_ID,
                                                 schema=[])

        main_page_content = agent_for_crawling._get_content_from_url(CALENDAR_URL)
        if not main_page_content:
            print(f"❌ FATAL: Could not retrieve content from the calendar URL. Aborting.")
            return

        event_list = []
        organizer_pattern = re.compile(r"^\s*\*\*(?P<city>[^*]+)\*\*\s*(?P<name>[^\[\n\r]+)")
        link_pattern = re.compile(r'\[(?P<details>.*?)\]\((?P<url>.*?)\)')
        for line in main_page_content.splitlines():
            organizer_match = organizer_pattern.match(line)
            if organizer_match:
                city, name = organizer_match.group('city').strip(), organizer_match.group('name').strip()
                current_organizer = f"{city} {name}"
                for link_match in link_pattern.finditer(line):
                    event_list.append(
                        {"organizer": current_organizer, "event_details": link_match.group('details').strip(),
                         "url": urljoin(CALENDAR_URL, link_match.group('url'))})

        if not event_list:
            print("🤷 No valid event links found on the calendar page after parsing. Aborting.")
            return
        print(f"✅ Regex successfully extracted {len(event_list)} total event instances.")

        schema = CYCLING_SCHEMA
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        output_filename = f"DefaultWebsites_{EVENT_TYPE}_{timestamp}.csv"
        output_filepath = os.path.join(effective_output_dir, output_filename)

        already_written_events = set()
        file_exists = os.path.exists(output_filepath)
        if file_exists:
            try:
                with open(output_filepath, 'r', newline='', encoding='utf-8') as f_read:
                    reader = csv.DictReader(f_read)
                    for row in reader:
                        if row.get('event'): already_written_events.add(row['event'])
                print(f"📄 Found {len(already_written_events)} event entries already in the CSV.")
            except Exception as e:
                print(f"   - ⚠️ Could not read existing CSV file: {e}")

        events_to_process = [e for e in event_list if
                             f"{e['organizer']} {e['event_details']}" not in already_written_events]
        if max_events is not None and max_events > 0:
            events_to_process = events_to_process[:max_events]

        if not events_to_process:
            print("✅ No new events to process. Output file is up to date.")
            if counter_callback: counter_callback(0, 0)
            return

        main_agent = MistralAnalystAgent(mistral_key=MISTRAL_API_KEY, search_key=SEARCH_API_KEY, cse_id=CSE_ID,
                                         schema=schema)
        total_events = len(events_to_process)
        processed_count = 0
        if counter_callback: counter_callback(processed_count, total_events)

        # --- BUG FIX: Moved try/except block inside the loop ---
        for i, event_info in enumerate(events_to_process):
            try:
                if stop_event and stop_event.is_set():
                    print("\n--- STOP SIGNAL RECEIVED ---")
                    print("Terminating agent process...")
                    break

                event_name = f"{event_info['organizer']} {event_info['event_details']}"
                event_url = event_info['url']
                print("\n" + "=" * 60)
                print(f"🏁 STARTING MISSION {i + 1}/{total_events} FOR: {event_name}")
                print("=" * 60)
                race_info = {"Festival": event_name, "Type": EVENT_TYPE}
                caching_key = main_agent.get_caching_key(f"{event_name}-{event_url.split('event-e-')[-1]}")
                cache_file_path = os.path.join(KNOWLEDGE_CACHE_DIR, f"{caching_key}.json")
                knowledge_base = None

                if os.path.exists(cache_file_path):
                    with open(cache_file_path, 'r', encoding='utf-8') as f:
                        knowledge_base = deserialize_knowledge_base(json.load(f))
                else:
                    knowledge_base = main_agent.run(race_info, direct_urls=[event_url])
                    if knowledge_base:
                        with open(cache_file_path, 'w', encoding='utf-8') as f:
                            json.dump(serialize_knowledge_base(knowledge_base), f, indent=4)

                if knowledge_base:
                    with open(output_filepath, 'a', newline='', encoding='utf-8') as output_file:
                        writer = csv.DictWriter(output_file, fieldnames=schema)
                        if not file_exists or output_file.tell() == 0:
                            writer.writeheader()
                            file_exists = True  # Ensure header is only written once

                        main_festival_name = event_info['organizer']
                        for variant_name, data in knowledge_base.items():
                            if row := format_final_row(main_festival_name, variant_name, data, schema):
                                writer.writerow(row)
                    print(f"✅ MISSION COMPLETE FOR: {event_name}")
                else:
                    failed_missions.append(event_name)

            except Exception as e:
                print(f"❌ An unexpected error occurred while processing '{event_name}': {e}")
                failed_missions.append(event_name)
                continue  # Continue to the next event
            finally:
                processed_count += 1
                if counter_callback: counter_callback(processed_count, total_events)

    except Exception as e:
        # This will catch initialization errors
        print(f"❌ A fatal error occurred during setup: {e}")
    finally:
        if agent_for_crawling: agent_for_crawling.shutdown()
        if main_agent: main_agent.shutdown()

        print("\n" + "=" * 60)
        print("🎉 CALENDAR CRAWL COMPLETE")
        if failed_missions:
            print("\n📋 Summary of Failed Missions:")
            for event in failed_missions: print(f"  - {event}")
        else:
            print("\n✅ All missions completed successfully.")
        print("=" * 60)


# --- START: New Website Processors ---
def process_manalimarathon_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "book-now-races href" in item: processed["link"] = item["book-now-races href"]
        if "d-flex" in item: processed["festivalName"] = item["d-flex"]
        if "barlow-regular (3)" in item: processed["date"] = item["barlow-regular (3)"]
        if processed: result.append(processed)
    return result


def process_adidas_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "r-6koalj href" in item: processed["link"] = item["r-6koalj href"]
        if "css-146c3p1" in item: processed["date"] = item["css-146c3p1"]
        if "css-146c3p1 (2)" in item: processed["festivalName"] = item["css-146c3p1 (2)"]
        if processed: result.append(processed)
    return result


def process_mysamay_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "col-12 src" in item: event["link"] = item["col-12 src"]
        if "col-12 (3)" in item: event["festivalName"] = item["col-12 (3)"]
        if "col-12 (4)" in item: event["city"] = item["col-12 (4)"]
        if "col-12 (5)" in item: event["date"] = item["col-12 (5)"]
        if "ng-star-inserted (2)" in item: event["registrationCost"] = item["ng-star-inserted (2)"]
        if event: result.append(event)
    return result


def process_sportives_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "text-decoration-none href" in item: event["link"] = item["text-decoration-none href"]
        if "card-title" in item: event["festivalName"] = item["card-title"]
        if "d-flex" in item: event["city"] = item["d-flex"]
        if "o_wevent_event_day" in item and "o_wevent_event_month" in item:
            event["date"] = f"{item['o_wevent_event_day']} {item['o_wevent_event_month']}"
        if event: result.append(event)
    return result


def process_anybodycanrun_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "wp-block-button__link href" in item: event["link"] = item["wp-block-button__link href"]
        if event: result.append(event)
    return result


def process_virtualrunneruk_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "card--race href" in item: event["link"] = item["card--race href"]
        if "card--race__title" in item: event["festivalName"] = item["card--race__title"]
        if "woocommerce-Price-amount" in item: event["registrationCost"] = item["woocommerce-Price-amount"]
        if event: result.append(event)
    return result


def process_runizen_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "transition href" in item: event["link"] = item["transition href"]
        if "mt-4" in item: event["city"] = item["mt-4"]
        if "text-sm" in item: event["date"] = item["text-sm"]
        if event: result.append(event)
    return result


def process_mfaadventures_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "menu-item href" in item: event["link"] = item["menu-item href"]
        if "menu-item" in item: event["festivalName"] = item["menu-item"]
        if event: result.append(event)
    return result


def process_novarace_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "ratio href" in item: event["link"] = item["ratio href"]
        if "hotelsCard__title" in item: event["festivalName"] = item["hotelsCard__title"]
        if "bg-dark-1" in item and "bg-danger" in item:
            event["date"] = f"{item['bg-danger']} {item['bg-dark-1']}"
        if event: result.append(event)
    return result


def process_dcfitnessclub_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "btn href" in item: event["link"] = item["btn href"]
        if "card-title" in item: event["festivalName"] = item["card-title"]
        if event: result.append(event)
    return result


def process_globeracers_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "rounded-md href" in item: event["link"] = item["rounded-md href"]
        if "text-lg" in item: event["festivalName"] = item["text-lg"]
        if event: result.append(event)
    return result


def process_crewfitclub_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "card href" in item: event["link"] = item["card href"]
        if "card-title" in item: event["festivalName"] = item["card-title"]
        if "card-body (3)" in item: event["date"] = item["card-body (3)"]
        if event: result.append(event)
    return result


def process_ektarun_json(data):
    result = []
    for item in data:
        event = OrderedDict()
        if "DjQEyU href" in item: event["link"] = item["DjQEyU href"]
        if "DjQEyU" in item: event["festivalName"] = item["DjQEyU"]
        if "v2vbgt" in item: event["date"] = item["v2vbgt"]
        if "xtenVZ" in item: event["city"] = item["xtenVZ"]
        if event: result.append(event)
    return result


def process_racemart_json(json_data):
    processed = []
    for item in json_data:
        event = OrderedDict()
        if "geodir-category-img-wrap href" in item: event["link"] = item["geodir-category-img-wrap href"]
        if "title-sin_map" in item: event["festivalName"] = item["title-sin_map"]
        if "text-ellipsis" in item: event["city"] = item["text-ellipsis"]
        if "price-level-item (4)" in item: event["registrationCost"] = item["price-level-item (4)"]
        if "geodir-category-img" in item and "geodir-category-img (2)" in item:
            event["date"] = f"{item['geodir-category-img']} {item['geodir-category-img (2)']}"
        if event: processed.append(event)
    return processed


def process_coachravinder_json(json_data):
    processed = []
    for event in json_data:
        new_event = OrderedDict()
        if "table href" in event: new_event["link"] = event["table href"]
        if "table (4)" in event: new_event["festivalName"] = event["table (4)"]
        if "table (3)" in event: new_event["city"] = event["table (3)"]
        if "table" in event: new_event["date"] = event["table"]
        if new_event: processed.append(new_event)
    return processed


def process_bookmyshow_json(json_data):
    processed = []
    for event in json_data:
        new_event = OrderedDict()
        if "sc-133848s-11 href" in event: new_event["link"] = event["sc-133848s-11 href"]
        if "sc-7o7nez-0" in event: new_event["festivalName"] = event["sc-7o7nez-0"]
        if "sc-7o7nez-0 (2)" in event: new_event["city"] = event["sc-7o7nez-0 (2)"]
        if "sc-7o7nez-0 (4)" in event: new_event["registrationCost"] = event["sc-7o7nez-0 (4)"]
        if new_event: processed.append(new_event)
    return processed


def process_hdor_json(json_data):
    processed = []
    for event in json_data:
        new_event = OrderedDict()
        if "MuiTypography-root href" in event: new_event["link"] = event["MuiTypography-root href"]
        if "MuiTypography-root" in event: new_event["festivalName"] = event["MuiTypography-root"]
        if "MuiTypography-root (2)" in event: new_event["date"] = event["MuiTypography-root (2)"]
        if "MuiBox-root" in event: new_event["registrationCost"] = event["MuiBox-root"]
        if new_event: processed.append(new_event)
    return processed


def process_citywoofer_json(json_data):
    processed = []
    for event in json_data:
        new_event = OrderedDict()
        if "dark-text href" in event: new_event["link"] = event["dark-text href"]
        if "dark-text" in event: new_event["festivalName"] = event["dark-text"]
        if "d-flex" in event: new_event["date"] = event["d-flex"]
        if "pt-1" in event: new_event["city"] = event["pt-1"]
        if "pt-3" in event: new_event["registrationCost"] = event["pt-3"]
        if new_event: processed.append(new_event)
    return processed


def process_sistersinsweat_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "btn_c href" in item: processed["link"] = item["btn_c href"]
        if "f_24" in item: processed["festivalName"] = item["f_24"]
        if "t-cream" in item: processed["city"] = item["t-cream"]
        if processed: result.append(processed)
    return result


def process_zenrun_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "DjQEyU href" in item: processed["link"] = item["DjQEyU href"]
        if "DjQEyU" in item: processed["festivalName"] = item["DjQEyU"]
        if "v2vbgt" in item: processed["date"] = item["v2vbgt"]
        if "xtenVZ" in item: processed["city"] = item["xtenVZ"]
        if processed: result.append(processed)
    return result


def process_zenmountain_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "tribe-events-calendar-list__event-featured-image-link href" in item: processed["link"] = item[
            "tribe-events-calendar-list__event-featured-image-link href"]
        if "tribe-events-calendar-list__event-datetime" in item: processed["date"] = item[
            "tribe-events-calendar-list__event-datetime"]
        if "tribe-events-c-small-cta__price" in item: processed["registrationCost"] = item[
            "tribe-events-c-small-cta__price"]
        if "tribe-events-calendar-list__event-venue-address" in item: processed["city"] = item[
            "tribe-events-calendar-list__event-venue-address"]
        if processed: result.append(processed)
    return result


def process_runindia_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "col-md-2 href" in item: processed["link"] = item["col-md-2 href"]
        if "col-xs-7" in item: processed["festivalName"] = item["col-xs-7"]
        if "col-xs-7 (2)" in item: processed["date"] = item["col-xs-7 (2)"]
        if processed: result.append(processed)
    return result


def process_default_website_data(data, website):
    configs = {
        'indiarunning': {
            'key_rename_map': {"md:grid href": "link", "line-clamp-2": "festivalName", "font-bold": "registrationCost",
                               "hidden": "city", "font-normal": "date"}},
        'townscript': {'key_rename_map': {"ls-card href": "link", "font-semibold": "festivalName",
                                          "md:text-lg": "registrationCost", "whitespace-no-wrap (2)": "city",
                                          "whitespace-no-wrap": "date"}},
        'bhaagoindia': {
            'key_rename_map': {"hover:bi-text-blue-600 href": "link", "hover:bi-text-blue-600": "festivalName",
                               "bi-text-sm": "date", "bi-text-sm (2)": "city"}}}
    if website not in configs: return []
    config, processed_list = configs[website], []
    for item in data:
        processed_data = {new_key: item.get(old_key) for old_key, new_key in config['key_rename_map'].items() if
                          item.get(old_key)}
        if processed_data.get("link"):
            processed_list.append(processed_data)
    return processed_list


# --- END: Website Processors ---

def get_website_processor(filename):
    """Auto-detects which processing function to use based on filename."""
    processors = {
        'manalimarathon': (process_manalimarathon_json, None), 'adidas': (process_adidas_json, None),
        'mysamay': (process_mysamay_json, None), 'sportives': (process_sportives_json, None),
        'anybodycanrun': (process_anybodycanrun_json, None), 'virtualrunneruk': (process_virtualrunneruk_json, None),
        'runizen': (process_runizen_json, None), 'mfaadventures': (process_mfaadventures_json, None),
        'novarace': (process_novarace_json, None), 'dcfitnessclub': (process_dcfitnessclub_json, None),
        'globeracers': (process_globeracers_json, None), 'crewfitclub': (process_crewfitclub_json, None),
        'ektarun': (process_ektarun_json, None), 'racemart': (process_racemart_json, None),
        'coachravinder': (process_coachravinder_json, None), 'bookmyshow': (process_bookmyshow_json, None),
        'hdor': (process_hdor_json, None), 'citywoofer': (process_citywoofer_json, None),
        'sistersinsweat': (process_sistersinsweat_json, None), 'zenrun': (process_zenrun_json, None),
        'zenmountain': (process_zenmountain_json, None), 'runindia': (process_runindia_json, None),
        'indiarunning': (process_default_website_data, 'indiarunning'),
        'townscript': (process_default_website_data, 'townscript'),
        'bhaagoindia': (process_default_website_data, 'bhaagoindia')
    }
    fn_lower = filename.lower()
    for key, (func, site_key) in processors.items():
        if key in fn_lower:
            return func, site_key
    return None, None


def load_and_process_files(input_files):
    all_events = []
    last_site_processed = None
    for file_path in input_files:
        print(f"   - Loading file: {file_path}")
        if not os.path.exists(file_path):
            print(f"   - ⚠️ Skipping missing file: {file_path}")
            continue

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f"   - ⚠️ Error reading JSON from {file_path}: {e}")
            continue

        processor_func, site_key = get_website_processor(os.path.basename(file_path))

        if processor_func:
            current_site = site_key or os.path.basename(file_path).split('-')[0]
            print(f"   - Detected processor for: {current_site}")

            if last_site_processed and current_site != last_site_processed:
                all_events.append({"link": "BLANK_ROW"})

            processed = processor_func(data, site_key) if site_key else processor_func(data)
            all_events.extend(processed)
            last_site_processed = current_site
        else:
            print(f"   - ⚠️ No processor found for file: {os.path.basename(file_path)}. Skipping.")

    return all_events


def run_default_websites_mode(input_files, output_dir_override=None, max_events=None, counter_callback=None,
                              stop_event=None):
    print("=" * 60)
    print(f"🚀 LAUNCHING Crawl4AI Agent {APP_VERSION} in Default Websites Mode...")
    print("=" * 60)

    type_discovery_agent = None
    failed_missions = []

    try:
        events_data = load_and_process_files(input_files)
        unique_events = {item['link']: item for item in reversed(events_data) if 'link' in item}.values()
        event_list = list(unique_events)
        print(f"✅ Extracted {len(event_list)} unique event links from provided files.")

        events_to_process = event_list
        if max_events is not None and max_events > 0:
            events_to_process = event_list[:max_events]

        total_to_process = len(events_to_process)
        if counter_callback: counter_callback(0, total_to_process)
        if not events_to_process:
            print("✅ No new events to process.")
            return

        effective_output_dir = output_dir_override if output_dir_override else OUTPUT_DIR
        schema_map = {"triathlon": TRIATHLON_SCHEMA, "run": RUNNING_SCHEMA, "running": RUNNING_SCHEMA,
                      "trail running": RUNNING_SCHEMA, "swimathon": SWIMMING_SCHEMA, "swimming": SWIMMING_SCHEMA,
                      "duathlon": DUATHLON_SCHEMA, "aquathlon": AQUATHLON_SCHEMA, "aquabike": AQUABIKE_SCHEMA,
                      "cycling": CYCLING_SCHEMA, "fitness racing": FITNESS_RACING_SCHEMA}

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")

        type_discovery_agent = MistralAnalystAgent(mistral_key=MISTRAL_API_KEY, search_key=SEARCH_API_KEY,
                                                   cse_id=CSE_ID, schema=[])
        processed_count = 0

        # --- BUG FIX: Moved try/except block inside the loop ---
        for i, event_info in enumerate(events_to_process):
            data_extraction_agent = None
            try:
                if stop_event and stop_event.is_set():
                    print("\n--- STOP SIGNAL RECEIVED ---")
                    print("Terminating agent process...")
                    break

                if event_info.get("link") == "BLANK_ROW":
                    continue

                event_url = event_info.get("link")
                if not event_url:
                    continue

                print("\n" + "=" * 60)
                print(f"🏁 STARTING MISSION {i + 1}/{total_to_process} FOR: {event_url}")

                event_type = type_discovery_agent.determine_event_type(event_url)
                if not event_type:
                    print(f"  - ❌ Could not determine event type. Skipping.")
                    failed_missions.append(f"{event_url} (Type determination failed)")
                    continue

                schema = schema_map.get(event_type.lower())
                if not schema:
                    print(f"  - ❌ No schema found for type '{event_type}'. Skipping.")
                    failed_missions.append(f"{event_url} (No schema for type '{event_type}')")
                    continue

                output_filename = f"DefaultWebsites_{event_type}_{timestamp}.csv"
                output_filepath = os.path.join(effective_output_dir, output_filename)
                file_exists = os.path.exists(output_filepath)

                with open(output_filepath, 'a', newline='', encoding='utf-8') as output_file:
                    writer = csv.DictWriter(output_file, fieldnames=schema)
                    if not file_exists:
                        writer.writeheader()

                    festival_name = event_info.get('festivalName') or event_info.get('event-name') or event_url
                    race_info = {"Festival": festival_name, "Type": event_type}
                    pre_filled_data = {k: v for k, v in event_info.items() if k in schema}

                    data_extraction_agent = MistralAnalystAgent(mistral_key=MISTRAL_API_KEY, search_key=SEARCH_API_KEY,
                                                                cse_id=CSE_ID, schema=schema)
                    caching_key = data_extraction_agent.get_caching_key(f"default-event-{event_url}")
                    cache_file_path = os.path.join(KNOWLEDGE_CACHE_DIR, f"{caching_key}.json")
                    knowledge_base = None

                    if os.path.exists(cache_file_path):
                        with open(cache_file_path, 'r', encoding='utf-8') as f:
                            knowledge_base = deserialize_knowledge_base(json.load(f))
                    else:
                        knowledge_base = data_extraction_agent.run(race_info, direct_urls=[event_url],
                                                                   pre_filled_data=pre_filled_data)
                        if knowledge_base:
                            with open(cache_file_path, 'w', encoding='utf-8') as f:
                                json.dump(serialize_knowledge_base(knowledge_base), f, indent=4)

                    if knowledge_base:
                        real_festival_name = festival_name
                        print(f"    - Using Event Name: {real_festival_name}")
                        for variant_name, data in knowledge_base.items():
                            if row := format_final_row(real_festival_name, variant_name, data, schema):
                                row['eventWebsite'] = event_url
                                writer.writerow(row)
                        print(f"✅ MISSION COMPLETE FOR: {real_festival_name}")
                    else:
                        failed_missions.append(f"{event_url} (No data extracted)")

            except Exception as e:
                print(f"❌ An unexpected error occurred while processing '{event_url}': {e}")
                failed_missions.append(f"{event_url} (Critical Error)")
                continue  # Continue to the next event
            finally:
                if data_extraction_agent: data_extraction_agent.shutdown()
                processed_count += 1
                if counter_callback: counter_callback(processed_count, total_to_process)

    except Exception as e:
        # This will catch initialization errors
        print(f"❌ A fatal error occurred during setup: {e}")
    finally:
        if type_discovery_agent: type_discovery_agent.shutdown()

        print("\n" + "=" * 60)
        print("🎉 DEFAULT WEBSITES RUN COMPLETE")
        if failed_missions:
            print("\n📋 Summary of Failed Missions:")
            for event in failed_missions: print(f"  - {event}")
        else:
            print("\n✅ All missions completed successfully.")
        print("=" * 60)


if __name__ == '__main__':
    print("To run the system, please use the UI by executing streamlit_app.py")