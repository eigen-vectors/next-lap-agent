# Crawl4AI_v2.py
# This is the main entry point for the Crawl4AI Agent System UI.

import sys
import os
import shutil
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QPushButton, QLabel, QFileDialog,
                             QStackedWidget, QLineEdit, QTextEdit, QFrame, QComboBox)
from PyQt5.QtCore import QThread, pyqtSignal, QObject, Qt
from PyQt5.QtGui import QTextCursor, QIntValidator

from config import CRAWL_CACHE_DIR, KNOWLEDGE_CACHE_DIR, OUTPUT_DIR, APP_VERSION, VECTOR_DB_PATH
from main import run_calendar_mode, run_default_websites_mode
from schemas import CHOICE_OPTIONS

from dotenv import load_dotenv


class Stream(QObject):
    new_text = pyqtSignal(str)

    def write(self, text): self.new_text.emit(str(text))

    def flush(self): pass


class MistralWorker(QThread):
    counter_updated = pyqtSignal(int, int)

    def __init__(self, env_path, output_path, mode, **kwargs):
        super().__init__()
        self.env_path, self.output_path, self.mode, self.kwargs = env_path, output_path, mode, kwargs
        self._is_running = True

    def run(self):
        try:
            # Smartly load .env file
            if self.env_path and os.path.exists(self.env_path):
                print(f"INFO: Loading environment variables from specified file: {self.env_path}")
                load_dotenv(dotenv_path=self.env_path, override=True)
            else:
                print("INFO: No .env file specified. Attempting to auto-detect in root folder.")
                load_dotenv(override=True)

            if not self._is_running: return

            counter_callback = self.counter_updated.emit

            if self.mode == "calendar":
                run_calendar_mode(
                    output_dir_override=self.output_path,
                    max_events=self.kwargs.get('max_events'),
                    counter_callback=counter_callback
                )
            elif self.mode == "default_websites":
                run_default_websites_mode(
                    input_files=self.kwargs.get('input_files'),
                    output_dir_override=self.output_path,
                    max_events=self.kwargs.get('max_events'),
                    counter_callback=counter_callback
                )
        except Exception as e:
            print(f"An error occurred in the Mistral Agent: {e}")

    def stop(self):
        if self._is_running:
            print("\n--- STOP SIGNAL RECEIVED ---")
            print("Terminating agent process. Please wait...")
            self._is_running = False
            self.terminate()
            self.wait(2000)
            print("--- AGENT TERMINATED ---")


class Crawl4AIApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"Crawl4AI Agent System - {APP_VERSION}")
        self.setGeometry(100, 100, 1000, 750)
        self.setMinimumSize(850, 650)
        self.stacked_widget = QStackedWidget()
        self.setCentralWidget(self.stacked_widget)

        self.home_screen = HomeScreen()
        self.mistral_screen = MistralScreen()

        self.stacked_widget.addWidget(self.home_screen)
        self.stacked_widget.addWidget(self.mistral_screen)

        self.home_screen.mistral_selected.connect(lambda: self.stacked_widget.setCurrentWidget(self.mistral_screen))

        self.mistral_screen.back_to_home.connect(self.go_to_home)

    def go_to_home(self):
        self.mistral_screen.reset_ui_state()
        self.stacked_widget.setCurrentWidget(self.home_screen)


class HomeScreen(QWidget):
    mistral_selected = pyqtSignal()

    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self);
        layout.setContentsMargins(50, 50, 50, 50)
        layout.setSpacing(15);
        layout.setAlignment(Qt.AlignCenter)
        title = QLabel(f"Crawl4AI Agent System");
        title.setObjectName("TitleLabel");
        title.setAlignment(Qt.AlignCenter)
        version = QLabel(APP_VERSION);
        version.setObjectName("SubtitleLabel");
        version.setAlignment(Qt.AlignCenter)
        subtitle = QLabel("Choose the agent to begin processing.");
        subtitle.setObjectName("SubtitleLabel");
        subtitle.setAlignment(Qt.AlignCenter)

        self.mistral_button = QPushButton("Mistral Agent Suite (Web Crawler)");
        self.mistral_button.setObjectName("PrimaryButton");
        self.mistral_button.clicked.connect(self.mistral_selected.emit)

        layout.addStretch(1);
        layout.addWidget(title);
        layout.addWidget(version);
        layout.addSpacing(30);
        layout.addWidget(subtitle)
        layout.addWidget(self.mistral_button);
        layout.addStretch(2)


class BaseAgentScreen(QWidget):
    back_to_home = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.worker = None
        self.main_layout = QVBoxLayout(self);
        self.main_layout.setContentsMargins(20, 15, 20, 20);
        self.main_layout.setSpacing(15)
        header_layout = QHBoxLayout()
        back_button = QPushButton("← Back");
        back_button.setObjectName("BackButton");
        back_button.clicked.connect(self.back_to_home.emit)
        header_layout.addWidget(back_button);
        header_layout.addStretch()
        self.main_layout.addLayout(header_layout)

    def _create_group_box(self, title):
        frame = QFrame();
        frame.setObjectName("GroupBox");
        layout = QVBoxLayout(frame)
        label = QLabel(title);
        label.setObjectName("GroupLabel");
        layout.addWidget(label)
        return frame, layout

    def _create_log_box(self):
        log_frame, log_layout = self._create_group_box("Live Log")
        self.log_output = QTextEdit();
        self.log_output.setReadOnly(True)
        log_layout.addWidget(self.log_output)
        return log_frame

    def browse_file(self, target_widget):
        path, _ = QFileDialog.getOpenFileName(self, "Select File", "", ".env files (*.env)");
        if path: target_widget.setText(path)

    def browse_multiple_files(self, target_widget):
        paths, _ = QFileDialog.getOpenFileNames(self, "Select File(s)", "", "JSON Files (*.json)");
        if paths: target_widget.setText("; ".join(paths))

    def browse_dir(self, target_widget):
        path = QFileDialog.getExistingDirectory(self, "Select Directory");
        if path: target_widget.setText(path)


class MistralScreen(BaseAgentScreen):
    def __init__(self):
        super().__init__()
        config_panel = QWidget();
        config_layout = QVBoxLayout(config_panel);
        config_layout.setContentsMargins(0, 0, 0, 0);
        config_layout.setSpacing(15)

        mode_frame, mode_layout = self._create_group_box("1. Select Mode")
        self.mode_selector = QComboBox();
        self.mode_selector.addItems(["Default Websites", "Crawl Cycling Calendar"])
        self.mode_selector.currentIndexChanged.connect(self.update_inputs_ui)
        mode_layout.addWidget(self.mode_selector)

        inputs_frame, inputs_layout = self._create_group_box("2. Configure Inputs")
        self.env_file_path = QLineEdit();
        self.env_file_path.setPlaceholderText(".env file path (optional, auto-detects)")
        browse_env_btn = QPushButton("Browse...");
        browse_env_btn.clicked.connect(lambda: self.browse_file(self.env_file_path))
        inputs_layout.addLayout(self.create_browse_layout(self.env_file_path, browse_env_btn))
        self.inputs_stack = QStackedWidget();
        self.setup_mode_inputs();
        inputs_layout.addWidget(self.inputs_stack)
        self.output_dir_path = QLineEdit();
        self.output_dir_path.setPlaceholderText(f"Output Directory (default: ./{OUTPUT_DIR})")
        browse_output_btn = QPushButton("Browse...");
        browse_output_btn.clicked.connect(lambda: self.browse_dir(self.output_dir_path))
        inputs_layout.addLayout(self.create_browse_layout(self.output_dir_path, browse_output_btn))

        run_frame, run_layout = self._create_group_box("3. Run Analysis")
        self.max_events_input = QLineEdit();
        self.max_events_input.setPlaceholderText("Max events to process (optional)")
        self.max_events_input.setValidator(QIntValidator(1, 9999))
        run_layout.addWidget(self.max_events_input)

        self.start_button = QPushButton("Start Processing");
        self.start_button.setObjectName("StartButton");
        self.start_button.clicked.connect(self.start_processing)
        self.stop_button = QPushButton("Stop Process");
        self.stop_button.setObjectName("StopButton");
        self.stop_button.setEnabled(False);
        self.stop_button.clicked.connect(self.stop_processing)
        run_layout.addWidget(self.start_button);
        run_layout.addWidget(self.stop_button)

        utilities_frame, utilities_layout = self._create_group_box("Utilities")
        clear_caches_button = QPushButton("Clear All Caches");
        clear_caches_button.clicked.connect(self.clear_all_caches)
        utilities_layout.addWidget(clear_caches_button)

        config_layout.addWidget(mode_frame);
        config_layout.addWidget(inputs_frame);
        config_layout.addWidget(run_frame);
        config_layout.addWidget(utilities_frame);
        config_layout.addStretch(1)
        log_panel = self._create_log_box()

        main_hbox = QHBoxLayout();
        main_hbox.addWidget(config_panel, 1);
        main_hbox.addWidget(log_panel, 2)

        self.progress_counter_label = QLabel("Events Processed: 0 / 0");
        self.progress_counter_label.setVisible(False)
        self.progress_counter_label.setAlignment(Qt.AlignCenter)

        bottom_layout = QVBoxLayout();
        bottom_layout.addLayout(main_hbox);
        bottom_layout.addWidget(self.progress_counter_label)
        self.main_layout.addLayout(bottom_layout)

    def create_browse_layout(self, line_edit, button):
        layout = QHBoxLayout();
        layout.addWidget(line_edit);
        layout.addWidget(button);
        return layout

    def setup_mode_inputs(self):
        self.default_websites_widget = QWidget()
        def_layout = QVBoxLayout(self.default_websites_widget);
        def_layout.setContentsMargins(0, 5, 0, 0);
        def_layout.setSpacing(10)
        def_info = QLabel("Select one or more pre-scraped JSON files.");
        def_info.setObjectName("InfoLabel");
        def_info.setWordWrap(True)
        self.input_files_path = QLineEdit();
        self.input_files_path.setPlaceholderText("Click Browse to select file(s)...")
        browse_files_btn = QPushButton("Browse...");
        browse_files_btn.clicked.connect(lambda: self.browse_multiple_files(self.input_files_path))
        def_layout.addWidget(def_info)
        def_layout.addLayout(self.create_browse_layout(self.input_files_path, browse_files_btn))
        self.inputs_stack.addWidget(self.default_websites_widget)

        self.calendar_widget = QWidget()
        cal_layout = QVBoxLayout(self.calendar_widget);
        cal_layout.setContentsMargins(0, 5, 0, 0)
        cal_info = QLabel("Crawls audaxindia.in for cycling events.");
        cal_info.setObjectName("InfoLabel")
        cal_layout.addWidget(cal_info);
        self.inputs_stack.addWidget(self.calendar_widget)

    def update_inputs_ui(self, index):
        self.inputs_stack.setCurrentIndex(index)

    def clear_all_caches(self):
        self.log_output.append("\n--- Clearing All Caches ---")
        for d, n in [(CRAWL_CACHE_DIR, "Crawl"), (KNOWLEDGE_CACHE_DIR, "Knowledge"),
                     (VECTOR_DB_PATH, "Vector Database")]:
            try:
                if os.path.exists(d): shutil.rmtree(d)
                os.makedirs(d);
                self.log_output.append(f"✅ Success: Cleared '{n}' cache.")
            except Exception as e:
                self.log_output.append(f"❌ Error clearing {n}: {e}")
        self.log_output.append("--- All Caches Cleared ---\n")

    def update_progress_counter(self, processed, total):
        self.progress_counter_label.setText(f"Events Processed: {processed} / {total}")

    def start_processing(self):
        self.log_output.clear();
        self.progress_counter_label.setText("Initializing...");
        self.progress_counter_label.setVisible(True)
        self.start_button.setEnabled(False);
        self.stop_button.setEnabled(True);
        self.start_button.setText("Processing...")
        mode_text = self.mode_selector.currentText();
        output_path = self.output_dir_path.text() or None
        env_path = self.env_file_path.text() or None;
        worker_mode, worker_kwargs = "", {}

        max_events_text = self.max_events_input.text()
        worker_kwargs['max_events'] = int(max_events_text) if max_events_text.isdigit() else None

        if "Default Websites" in mode_text:
            worker_mode = "default_websites"
            input_files = [p.strip() for p in self.input_files_path.text().split(';') if p.strip()]
            if not input_files:
                self.log_output.append("❌ Error: Please select at least one input file.");
                self.on_processing_finished();
                return
            worker_kwargs['input_files'] = input_files
        elif "Calendar" in mode_text:
            worker_mode = "calendar"

        self.worker = MistralWorker(env_path=env_path, output_path=output_path, mode=worker_mode, **worker_kwargs)
        self.worker.counter_updated.connect(self.update_progress_counter)
        self.worker.start();
        self.worker.finished.connect(self.on_processing_finished)

    def stop_processing(self):
        if self.worker: self.worker.stop()
        self.on_processing_finished(stopped_by_user=True)

    def on_processing_finished(self, stopped_by_user=False):
        if stopped_by_user:
            self.log_output.append("\n--- PROCESSING STOPPED BY USER ---")
        elif self.worker and self.worker._is_running:
            self.log_output.append("\n--- PROCESSING FINISHED ---")
        self.reset_ui_state()

    def reset_ui_state(self):
        self.start_button.setText("Start Processing");
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False);
        self.progress_counter_label.setVisible(False)
        self.worker = None


def main_ui():
    app = QApplication(sys.argv)
    app.setStyleSheet("""
        QWidget { font-family: 'Inter', 'Segoe UI', sans-serif; font-size: 10pt; color: #e0e2e4; background-color: #1e2124; }
        QMainWindow { background-color: #1e2124; }
        #TitleLabel { font-size: 26pt; font-weight: 600; color: #ffffff; }
        #SubtitleLabel { font-size: 11pt; color: #8e9297; padding-bottom: 10px; }
        QPushButton { background-color: #40444b; color: #ffffff; border: none; padding: 9px 16px; border-radius: 5px; font-weight: 500; }
        QPushButton:hover { background-color: #5865f2; }
        QPushButton:disabled { background-color: #2c2f33; color: #72767d; }
        #PrimaryButton, #SecondaryButton { font-size: 13pt; font-weight: bold; min-height: 45px; }
        #PrimaryButton { background-color: #5865f2; } #PrimaryButton:hover { background-color: #4f5bda; }
        #SecondaryButton { background-color: #4f545c; } #SecondaryButton:hover { background-color: #5c626b; }
        #BackButton { background-color: transparent; border: 1px solid #40444b; font-weight: normal; padding: 6px 12px; max-width: 100px; }
        #BackButton:hover { background-color: #40444b; border-color: #5865f2; }
        #StartButton { background-color: #22a55b; font-size: 11pt; font-weight: bold; min-height: 40px; }
        #StartButton:hover { background-color: #1f9450; }
        #StopButton { background-color: #da373c; font-size: 11pt; font-weight: bold; min-height: 40px; }
        #StopButton:hover { background-color: #c43136; }
        QLineEdit, QComboBox { background-color: #2c2f33; border: 1px solid #40444b; padding: 8px; border-radius: 4px; color: #e0e2e4; min-height: 20px; }
        QLineEdit:focus, QComboBox:focus { border-color: #5865f2; }
        QComboBox::drop-down { border: none; }
        #GroupBox { background-color: #2c2f33; border-radius: 8px; }
        #GroupLabel { font-size: 11pt; font-weight: bold; color: #ffffff; padding: 5px 0 8px 5px; }
        #InfoLabel { background-color: transparent; border: none; padding: 10px; color: #b9bbbe; font-style: italic; }
        QTextEdit { font-family: 'Consolas', 'Monaco', monospace; background-color: #18191c; color: #dcdfe0; border: 1px solid #40444b; border-radius: 4px; padding: 5px; }
    """)
    window = Crawl4AIApp()

    def write_to_logs(text):
        current_widget = window.stacked_widget.currentWidget()
        if hasattr(current_widget, 'log_output') and isinstance(current_widget.log_output, QTextEdit):
            log_box = current_widget.log_output;
            log_box.moveCursor(QTextCursor.End)
            log_box.insertPlainText(text);
            log_box.ensureCursorVisible()

    sys.stdout = Stream(new_text=write_to_logs);
    sys.stderr = sys.stdout;
    window.show();
    sys.exit(app.exec_())


if __name__ == '__main__':
    os.makedirs(CRAWL_CACHE_DIR, exist_ok=True);
    os.makedirs(KNOWLEDGE_CACHE_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    main_ui()