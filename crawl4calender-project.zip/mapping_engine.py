# mapping_engine.py

import re, json, os
from datetime import datetime

try:
    from dateutil import parser as dateparser
except ImportError:
    dateparser = None
from difflib import SequenceMatcher

# -------------------------
# Config / target schema
# -------------------------
TARGET_FIELDS = [
    "title", "category", "date", "start_date", "end_date", "location", "city", "state", "country",
    "distance_options", "price", "currency", "event_url", "ticket_url", "image_url", "description", "raw"
]

# Global hints: substring matches (extendable)
KEY_HINTS = {
    "title": ["title", "name", "dark-text", "line-clamp", "heading", "_container", "event-name"],
    "category": ["cat", "type", "pl-1_5", "activity", "sport", "running", "run", "cycling", "swim", "triathlon"],
    "date": ["date", "time", "text-uppercase", "text-xl", "start", "when", "font-normal"],
    "location": ["location", "address", "venue", "place", "text-truncate", "hidden"],
    "price": ["price", "cost", "fee", "pt-3", "₹", "rs", "price-text", "fee-", "font-bold"],
    "event_url": ["href", "url", "link", "md:grid", "registration", "event", "/e/"],
    "ticket_url": ["ticket", "checkout", "book", "purchase"],
    "image_url": ["image", "img", "banner", "src", "cover"],
    "distance_options": ["3k", "5k", "10k", "km", "mile", "marathon", "runningDistance", "cyclingDistance"]
}


# -------------------------
# Helpers
# -------------------------
def normalize_key(k):
    return re.sub(r'[^a-z0-9 ]', ' ', k.lower()).strip()


def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()


def is_url(s):
    return isinstance(s, str) and re.search(r'https?://', s)


def looks_like_date(s):
    if not isinstance(s, str) or not dateparser: return False
    try:
        # Provide a default date to handle cases where only time is present
        if s.isdigit() and len(s) < 4: return False
        _ = dateparser.parse(s, fuzzy=True, default=datetime(2000, 1, 1))
        return True
    except Exception:
        return False


def looks_like_price(s):
    if not isinstance(s, str): return False
    return bool(re.search(r'₹|\$|usd|inr|free|\d{2,}', s, re.IGNORECASE))


def looks_like_image(s):
    return isinstance(s, str) and re.search(r'\.(jpg|jpeg|png|webp|gif)(\?.*)?$', s, re.IGNORECASE)


def find_distance_tokens(s):
    if not isinstance(s, str): return []
    # Match standard distances and also keywords
    distances = re.findall(r'\b\d+\.?\d*\s*k\b|\b\d+\s*km\b|\bhalf marathon\b|\bfull marathon\b|\bmarathon\b', s,
                           re.IGNORECASE)
    return [d.strip() for d in distances]


# -------------------------
# Core mapping logic
# -------------------------
def rule_map_key(key):
    k = normalize_key(key)
    for field, hints in KEY_HINTS.items():
        for h in hints:
            if h in k:
                return field, "rule"
    best = (None, 0)
    for field, hints in KEY_HINTS.items():
        for h in hints:
            score = similar(k, h)
            if score > best[1]:
                best = (field, score)
    if best[1] > 0.75:
        return best[0], "fuzzy"
    return None, None


def infer_by_value(key, val):
    if is_url(val):
        v_lower = val.lower()
        if "ticket" in v_lower or "checkout" in v_lower or "book" in v_lower:
            return "ticket_url", "value_infer"
        if looks_like_image(val):
            return "image_url", "value_infer"
        return "event_url", "value_infer"
    if looks_like_image(val):
        return "image_url", "value_infer"
    if looks_like_price(val):
        return "price", "value_infer"
    if looks_like_date(val):
        return "date", "value_infer"
    if find_distance_tokens(val):
        return "distance_options", "value_infer"
    if isinstance(val, str) and len(val.split()) > 2 and any(
            x in val.lower() for x in ["road", "park", "street", "city", "india", "usa", "venue"]):
        return "location", "value_infer"
    return None, None


def normalize_date(s):
    if not dateparser: return s
    try:
        dt = dateparser.parse(s, fuzzy=True)
        return dt.date().isoformat()
    except Exception:
        return s


def normalize_price(s):
    if not isinstance(s, str): return s, ""
    if "free" in s.lower(): return "0", ""
    # A more robust regex to find any number in the string
    m = re.search(r'(\d[\d,.]*)', s)
    if not m: return s, ""

    currency_match = re.search(r'([₹$]|inr|usd)', s, re.IGNORECASE)
    currency = currency_match.group(1) if currency_match else "₹"

    amount = re.sub(r'[^\d.]', '', m.group(1))
    return amount, currency


# -------------------------
# Mapping Engine
# -------------------------
def map_record(raw):
    """
    Performs a first pass mapping using rules and heuristics.
    Returns high-confidence mappings and ambiguous/unmapped data.
    """
    flat = {k: v for k, v in raw.items() if v}  # Ignore empty values

    high_confidence_mappings = {}
    ambiguous_data = {}

    mapped_keys = set()

    # Pass 1: High-confidence rule-based mapping
    for k, v in flat.items():
        assigned_field, method = rule_map_key(k)
        if method == "rule":
            if assigned_field not in high_confidence_mappings:
                high_confidence_mappings[assigned_field] = v
                mapped_keys.add(k)

    # Pass 2: Value-based inference for remaining items
    for k, v in flat.items():
        if k in mapped_keys:
            continue
        assigned_field, method = infer_by_value(k, v)
        if assigned_field:
            # For distance, we aggregate instead of replacing
            if assigned_field == "distance_options":
                if assigned_field not in high_confidence_mappings: high_confidence_mappings[assigned_field] = []
                high_confidence_mappings[assigned_field].extend(find_distance_tokens(str(v)))
            elif assigned_field not in high_confidence_mappings:
                high_confidence_mappings[assigned_field] = v
            mapped_keys.add(k)

    # Collect all unmapped data as ambiguous
    for k, v in flat.items():
        if k not in mapped_keys:
            ambiguous_data[k] = v

    # Post-process and normalize high-confidence values
    normalized_confidence_mappings = {}
    for key, value in high_confidence_mappings.items():
        if key == "date":
            normalized_confidence_mappings[key] = normalize_date(value)
        elif key == "price":
            amount, currency = normalize_price(value)
            normalized_confidence_mappings["price"] = amount
            if currency:
                normalized_confidence_mappings["currency"] = currency
        elif key == "distance_options":
            if isinstance(value, list):
                dists = [d.upper().replace("KM", "K").replace(" ", "") for d in value]
                normalized_confidence_mappings[key] = list(dict.fromkeys(dists))
        else:
            normalized_confidence_mappings[key] = value

    return normalized_confidence_mappings, ambiguous_data