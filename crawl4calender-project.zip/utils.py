# utils.py

import os
import re
import csv
import json
import ftfy
from dateutil.parser import parse as date_parse

from schemas import DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS
from config import MIN_CONFIDENCE_THRESHOLD
from agent import Field


def extract_event_links(markdown: str):
    """
    Extract all IndiaRunning and Townscript event registration links robustly.
    """
    indiarunning_pattern = r"https:\/\/registrations\.indiarunning\.com\/[^\)]+"
    townscript_pattern = r"https:\/\/www\.townscript\.com\/e\/[a-zA-Z0-9\-_]+"
    links = re.findall(f"{indiarunning_pattern}|{townscript_pattern}", markdown)
    return list(dict.fromkeys(links))


def serialize_knowledge_base(knowledge_base: dict) -> dict:
    serializable_kb = {}
    for variant, data in knowledge_base.items():
        serializable_kb[variant] = {field_name: field_obj.to_dict() for field_name, field_obj in data.items()}
    return serializable_kb


def deserialize_knowledge_base(cached_data: dict) -> dict:
    knowledge_base = {}
    for variant, data in cached_data.items():
        knowledge_base[variant] = {
            field_name: Field(
                value=field_data.get('value'),
                confidence=field_data.get('confidence', 0.0),
                sources=field_data.get('sources', []),
                inferred_by=field_data.get('inferred_by', '')
            ) for field_name, field_data in data.items()
        }
    return knowledge_base


def format_final_row(festival_name_input: str, variant_name: str, data: dict, schema: list) -> dict | None:
    def get_value(field_name: str) -> any:
        field_obj = data.get(field_name)
        if not isinstance(field_obj, Field): return ""
        min_thresh = 0.45 if "inference" in field_obj.inferred_by else MIN_CONFIDENCE_THRESHOLD
        if field_obj.confidence >= min_thresh:
            return field_obj.value
        return ""

    def finalize_value(value: any) -> str:
        if value is None: return ""
        text = ftfy.fix_text(str(value)).strip()
        if text.lower() in ["na", "n/a", "", "none", "not specified", "null", "true", "false"]: return ""
        return text

    def find_final_price(data_struct):
        """Recursively search a dictionary for the most likely final/standard price."""
        if isinstance(data_struct, dict):
            for key in ['final', 'standard', 'price']:
                if key in data_struct:
                    value = data_struct[key]
                    if isinstance(value, (int, float)): return value
                    if isinstance(value, str) and value.isdigit(): return int(value)
                    if isinstance(value, dict): return find_final_price(value)

            last_numeric_val = None
            for key, value in data_struct.items():
                result = find_final_price(value)
                if result is not None: last_numeric_val = result
            return last_numeric_val

        if isinstance(data_struct, list):
            last_numeric_val = None
            for item in data_struct:
                result = find_final_price(item)
                if result is not None: last_numeric_val = result
            return last_numeric_val
        return None

    row = {}
    for key in schema:
        if key in DEFAULT_BLANK_FIELDS:
            row[key] = ""
            continue

        raw_value = finalize_value(get_value(key))

        try:
            if raw_value and raw_value.startswith('{') and raw_value.endswith('}'):
                parsed_json = json.loads(raw_value)
                if isinstance(parsed_json, dict):
                    if key == 'registrationCost':
                        price = find_final_price(parsed_json)
                        raw_value = str(price) if price is not None else raw_value
                    elif key == 'organiser':
                        raw_value = parsed_json.get('name', raw_value)
                    elif key == 'firstEdition':
                        raw_value = parsed_json.get('year', raw_value)
                    elif key == 'lastDate':
                        raw_value = parsed_json.get('registrationCloses',
                                                    parsed_json.get('closes', parsed_json.get('endDate', raw_value)))
                    elif key == 'ageLimitation':
                        age_limits = {k: v for k, v in parsed_json.items() if v}
                        if age_limits: raw_value = list(age_limits.values())[0]
        except (json.JSONDecodeError, TypeError):
            pass

        cleaned_value = finalize_value(raw_value)
        if key == "city":
            row[key] = cleaned_value.split(',')[0].strip()
        elif key in CHOICE_OPTIONS:
            found = False
            for option in CHOICE_OPTIONS[key]:
                if re.search(r'\b' + re.escape(option) + r'\b', cleaned_value, re.IGNORECASE):
                    row[key] = option
                    found = True
                    break
            if not found: row[key] = ""
        elif key == "participationType":
            row[key] = re.sub(r"[\[\]\'\"]", "", cleaned_value).replace(",", ", ")
        elif key == "aidStations":
            row[key] = "Yes" if cleaned_value.startswith('[') and len(cleaned_value) > 2 else cleaned_value
        elif key in ["runningDistance", "cyclingDistance"]:
            match = re.search(r'(\d+\.?\d*)', cleaned_value)
            if match:
                val = float(match.group(1))
                row[key] = "" if val > 1900 else str(val)
            else:
                row[key] = ""
        elif key in ["date", "lastDate"]:
            try:
                dt = date_parse(cleaned_value, fuzzy=True, dayfirst=True)
                if dt.year >= 2024:
                    row[key] = dt.strftime("%d/%m/%Y")
                else:
                    row[key] = ""
            except (ValueError, TypeError):
                row[key] = ""
        elif key == "startTime":
            try:
                row[key] = date_parse(cleaned_value, fuzzy=True).strftime("%I:%M %p")
            except (ValueError, TypeError):
                row[key] = ""
        else:
            row[key] = cleaned_value

    if str(variant_name).startswith('http'):
        row["event"] = festival_name_input
    elif festival_name_input and festival_name_input.lower() not in variant_name.lower():
        row["event"] = f"{festival_name_input} - {variant_name}"
    else:
        row["event"] = variant_name

    if not row.get("organiser") and festival_name_input:
        row["organiser"] = festival_name_input

    if row.get("date"):
        try:
            dt = date_parse(row["date"], dayfirst=True)
            row["month"] = dt.strftime("%B")
            year_str = str(dt.year)
            row["editionYear"], row["lastEdition"] = year_str, year_str
            first_ed_str = str(row.get("firstEdition", ""))
            if first_ed_str and first_ed_str.isdigit():
                count = int(year_str) - int(first_ed_str) + 1
                row["countEditions"] = str(count) if count > 0 else "1"
            else:
                row["countEditions"] = "1"
        except (ValueError, TypeError):
            pass

    if not row.get("restrictedTraffic"): row["restrictedTraffic"] = "Yes"
    if not row.get("aidStations"): row["aidStations"] = "Yes"
    if not row.get("approvalStatus"): row["approvalStatus"] = "Approved"

    for key in DEFAULT_BLANK_FIELDS:
        if key in row: row[key] = ""

    return row


def process_default_website_data(data, website):
    configs = {
        'indiarunning': {
            'keys_to_remove': ["w-full src", "w-full src (2)", "mx-2", "text-xs", "w-4 src", "inline-block (6)",
                               "flex src", "flex src (2)"],
            'key_rename_map': {"md:grid href": "link", "text-xl": "date", "text-xs (2)": "month",
                               "line-clamp-2": "festivalName", "pl-1_5": "type", "font-normal": "lastDate",
                               "font-bold": "registrationCost", "hidden": "city"}
        },
        'townscript': {
            'keys_to_remove': ["h-48 src", "font-semibold", "font-semibold (2)", "text-xs"],
            'key_rename_map': {"ls-card href": "link", "font-semibold": "festivalName",
                               "md:text-lg": "registrationCost", "whitespace-no-wrap (2)": "city",
                               "whitespace-no-wrap": "date"}
        },
        'bhaagoindia': {
            'keys_to_remove': ["bi-truncate", "bi-text-xs (3)", "bi-flex-1 href (2)", "bi-text-sm href",
                               "bi-text-sm href (2)", "bi-text-sm href (3)", "bi-text-sm href (4)",
                               "bi-inline-flex href", "bi-inline-flex href (2)", "bi-inline-flex href (3)",
                               "bi-inline-flex href (4)"],
            'key_rename_map': {"hover:bi-text-blue-600 href": "link", "hover:bi-text-blue-600": "festivalName",
                               "bi-text-sm": "date", "bi-text-sm (2)": "city"}
        }}
    if website not in configs: return []
    config, processed_list = configs[website], []
    for item in data:
        processed_data = {}
        for key, value in item.items():
            if key in config['keys_to_remove']: continue
            if website == 'townscript' and key == "whitespace-no-wrap": value = value.split(" - ")[0].strip()
            new_key = config['key_rename_map'].get(key, key)
            processed_data[new_key] = value
        processed_list.append(processed_data)
    return processed_list


def load_file(file_path, is_discover_input=False):
    if not os.path.exists(file_path): print(f"⚠️ Skipping missing file: {file_path}"); return None, None
    _, ext = os.path.splitext(file_path)
    try:
        if ext.lower() == '.json':
            with open(file_path, 'r', encoding='utf-8') as f:
                return 'json', json.load(f) or []
        elif ext.lower() == '.csv' and not is_discover_input:
            data = []
            with open(file_path, 'r', newline='', encoding='utf-8') as f:
                reader = csv.reader(f)
                header = next(reader, None)
                if not header: return 'csv', []

                link_col_idx = -1
                for idx, col_name in enumerate(header):
                    if col_name.lower() in ['links', 'link', 'url', 'eventwebsite']:
                        link_col_idx = idx
                        break
                if link_col_idx == -1: return 'csv', []

                for row in reader:
                    if len(row) > link_col_idx and row[link_col_idx].strip():
                        data.append(row[link_col_idx])
            return 'csv', data
        else:
            print(f"⚠️ Unsupported file extension for this mode: {ext}.");
            return None, None
    except Exception as e:
        print(f"⚠️ Error reading {file_path}: {e}");
        return None, None