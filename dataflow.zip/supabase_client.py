# supabase_client.py

import time
from supabase import create_client, Client
from functools import wraps

from config import SUPABASE_URL, SUPABASE_KEY, SUPABASE_SERVICE_ROLE_KEY

# Global client - initialized to None. This will hold our singleton instance.
supabase: Client = None

def get_supabase_client() -> Client | None:
    """
    Singleton accessor for the Supabase client.
    Initializes the client on the first call and returns the existing instance on subsequent calls.
    """
    global supabase
    if supabase is None:
        # If the client is not initialized, call the init function.
        init_supabase_client()
    return supabase

def init_supabase_client():
    """
    Initializes the global Supabase client. This should only be called by get_supabase_client().
    """
    global supabase
    if not all([SUPABASE_URL, SUPABASE_KEY, SUPABASE_SERVICE_ROLE_KEY]):
        print("[ERROR] Supabase credentials are not configured. Check your .env file.")
        supabase = None
        return

    try:
        print("[INFO] Initializing Supabase client...")
        # Use the service role key for admin-level permissions
        supabase = create_client(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY)
        print("  - [SUCCESS] Supabase client initialized.")
    except Exception as e:
        print(f"[ERROR] Failed to connect to Supabase: {e}")
        supabase = None

# --- Decorator for resilience ---
def supabase_operation(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # Always get the client via the getter to ensure it's initialized.
        client = get_supabase_client()
        if not client:
            error_message = "Supabase client not initialized."
            print(f"[ERROR] Cannot perform '{func.__name__}': {error_message}")
            # Provide a consistent return type for different function signatures
            if "delete" in func.__name__:
                return False, error_message
            elif "list" in func.__name__:
                return []
            return None
        
        for attempt in range(3):
            try:
                # Pass the guaranteed valid client to the actual function if needed, or rely on the module-level one
                return func(*args, **kwargs)
            except Exception as e:
                print(f"[WARNING] Supabase operation '{func.__name__}' failed on attempt {attempt + 1}: {e}")
                if attempt < 2:
                    time.sleep(2 ** attempt)
        
        error_message = f"Supabase operation '{func.__name__}' failed after multiple retries."
        print(f"[ERROR] {error_message}")
        if "delete" in func.__name__:
            return False, error_message
        elif "list" in func.__name__:
            return []
        return None
    return wrapper

# --- Client Functions (No longer call init_supabase_client directly) ---

@supabase_operation
def get_knowledge_cache(event_key: str) -> dict | None:
    """Retrieves a processed event from the knowledge_cache table."""
    client = get_supabase_client()
    response = client.table('knowledge_cache').select('data').eq('event_key', event_key).limit(1).execute()
    if response.data:
        return response.data[0].get('data')
    return None

@supabase_operation
def set_knowledge_cache(event_key: str, data: dict):
    """Upserts a processed event into the knowledge_cache table."""
    client = get_supabase_client()
    client.table('knowledge_cache').upsert({
        'event_key': event_key,
        'data': data
    }).execute()
    print(f"  - [SUCCESS] Supabase: Knowledge cache saved for '{event_key}'.")

@supabase_operation
def download_from_storage(file_path: str) -> str | None:
    """Downloads a file's content from the 'crawl_cache' bucket."""
    client = get_supabase_client()
    response = client.storage.from_('crawl_cache').download(file_path)
    return response.decode('utf-8') if response else None

@supabase_operation
def upload_to_storage(file_path: str, content: str):
    """Uploads content to a file in the 'crawl_cache' bucket."""
    client = get_supabase_client()
    try:
        client.storage.from_('crawl_cache').upload(
            file_path, content.encode('utf-8'), {"upsert": True}
        )
        print(f"  - [SUCCESS] Supabase: Saved '{file_path}' to Storage.")
    except Exception as e:
        print(f"  - [WARNING] Supabase: Could not upload '{file_path}' to storage: {e}")