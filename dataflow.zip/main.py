# main.py

import os
import re
import csv
import json
import shutil
import argparse
from datetime import datetime
from urllib.parse import urljoin
from collections import OrderedDict

from agent import MistralAnalystAgent, Field, AgentInitializationError
from config import (
    MISTRAL_API_KEY, MISTRAL_API_KEY_1, SEARCH_API_KEY, CSE_ID,
    OUTPUT_DIR, KNOWLEDGE_CACHE_DIR, CRAWL_CACHE_DIR, APP_VERSION
)
from schemas import (
    TRIATHLON_SCHEMA, RUNNING_SCHEMA, SWIMMING_SCHEMA, DUATHLON_SCHEMA,
    AQUATHLON_SCHEMA, AQUABIKE_SCHEMA, CYCLING_SCHEMA, FITNESS_RACING_SCHEMA,
)
from utils import (
    serialize_knowledge_base, deserialize_knowledge_base, format_final_row
)


# --- START: CalendarCrawl Website Processors ---
# These functions are specific to the 'default_websites' mode
def process_manalimarathon_json(json_data):
    result = []
    for item in json_data:
        processed = OrderedDict()
        if "book-now-races href" in item: processed["link"] = item["book-now-races href"]
        if "d-flex" in item: processed["festivalName"] = item["d-flex"]
        if "barlow-regular (3)" in item: processed["date"] = item["barlow-regular (3)"]
        if processed: result.append(processed)
    return result

def process_default_website_data(data, website):
    configs = {
        'indiarunning': {
            'key_rename_map': {"md:grid href": "link", "line-clamp-2": "festivalName", "font-bold": "registrationCost",
                               "hidden": "city", "font-normal": "date"}},
        'townscript': {'key_rename_map': {"ls-card href": "link", "font-semibold": "festivalName",
                                          "md:text-lg": "registrationCost", "whitespace-no-wrap (2)": "city",
                                          "whitespace-no-wrap": "date"}},
        'bhaagoindia': {
            'key_rename_map': {"hover:bi-text-blue-600 href": "link", "hover:bi-text-blue-600": "festivalName",
                               "bi-text-sm": "date", "bi-text-sm (2)": "city"}}}
    if website not in configs: return []
    config, processed_list = configs[website], []
    for item in data:
        processed_data = {new_key: item.get(old_key) for old_key, new_key in config['key_rename_map'].items() if
                          item.get(old_key)}
        if processed_data.get("link"):
            processed_list.append(processed_data)
    return processed_list

def get_website_processor(filename):
    """Auto-detects which processing function to use based on filename."""
    processors = {
        'manalimarathon': (process_manalimarathon_json, None),
        'indiarunning': (process_default_website_data, 'indiarunning'),
        'townscript': (process_default_website_data, 'townscript'),
        'bhaagoindia': (process_default_website_data, 'bhaagoindia')
    }
    fn_lower = filename.lower()
    for key, (func, site_key) in processors.items():
        if key in fn_lower:
            return func, site_key
    return None, None

def load_and_process_files(input_files):
    all_events = []
    last_site_processed = None
    for file_path in input_files:
        print(f"   - Loading file: {file_path}")
        if not os.path.exists(file_path):
            print(f"   - [WARNING] Skipping missing file: {file_path}")
            continue

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            print(f"   - [WARNING] Error reading JSON from {file_path}: {e}")
            continue

        processor_func, site_key = get_website_processor(os.path.basename(file_path))

        if processor_func:
            current_site = site_key or os.path.basename(file_path).split('-')[0]
            print(f"   - Detected processor for: {current_site}")

            if last_site_processed and current_site != last_site_processed:
                all_events.append({"link": "BLANK_ROW"})

            processed = processor_func(data, site_key) if site_key else processor_func(data)
            all_events.extend(processed)
            last_site_processed = current_site
        else:
            print(f"   - [WARNING] No processor found for file: {os.path.basename(file_path)}. Skipping.")

    return all_events
# --- END: CalendarCrawl Website Processors ---


def run_web_analyst_mode(input_file_path, output_dir_override=None, max_events=None):
    """
    Original logic from Crawl4AI. Takes an event list, searches the web, and extracts data.
    """
    print("=" * 60)
    print(f"MODE: Web Research Analyst (Crawl4AI) | Version: {APP_VERSION}")
    print("=" * 60)

    effective_output_dir = output_dir_override or OUTPUT_DIR
    print(f"[INFO] Output directory set to: {os.path.abspath(effective_output_dir)}")

    try:
        with open(input_file_path, 'r', encoding='utf-8') as f:
            races = json.load(f)
        races.sort(key=lambda x: x.get('Priority', 99))
        print(f"[SUCCESS] Found {len(races)} events to process from '{input_file_path}'.")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"[ERROR] CONFIGURATION ERROR: Could not read '{input_file_path}'. Error: {e}")
        return

    if max_events is not None and max_events > 0:
        races = races[:max_events]
        print(f"[INFO] Limiting run to a maximum of {max_events} events.")


    grouped_races, failed_missions = {}, []
    for race in races:
        race_type = race.get("Type", "Unknown").lower()
        if race_type not in grouped_races: grouped_races[race_type] = []
        grouped_races[race_type].append(race)

    csv_writers, output_files = {}, {}
    agent = None

    try:
        for race_type, race_list in grouped_races.items():
            schema_map = {"triathlon": TRIATHLON_SCHEMA, "run": RUNNING_SCHEMA, "running": RUNNING_SCHEMA, "trail running": RUNNING_SCHEMA,
                          "swimming": SWIMMING_SCHEMA, "swimathon": SWIMMING_SCHEMA, "duathlon": DUATHLON_SCHEMA, "aquathlon": AQUATHLON_SCHEMA,
                          "aquabike": AQUABIKE_SCHEMA, "cycling": CYCLING_SCHEMA, "fitness racing": FITNESS_RACING_SCHEMA}
            schema = schema_map.get(race_type)
            if not schema:
                print(f"[WARNING] Skipping unknown race type '{race_type}'.")
                continue

            agent = MistralAnalystAgent(mistral_key_1=MISTRAL_API_KEY, mistral_key_2=MISTRAL_API_KEY_1,
                                        search_key=SEARCH_API_KEY, cse_id=CSE_ID, schema=schema)

            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            output_filename = f"Crawl4AI_WebAnalyst_{race_type}_{timestamp}.csv"
            output_filepath = os.path.join(effective_output_dir, output_filename)
            print(f"\n[INFO] Processing {len(race_list)} '{race_type}' events. Output will be saved to: {output_filepath}")

            output_files[race_type] = open(output_filepath, 'w', newline='', encoding='utf-8')
            writer = csv.DictWriter(output_files[race_type], fieldnames=schema)
            writer.writeheader()
            csv_writers[race_type] = writer

            for i, race_info in enumerate(race_list):
                event_name = race_info.get("Festival")
                if not event_name:
                    print(f"[WARNING] Skipping item #{i + 1} as it has no 'Festival' name.")
                    continue

                print("\n" + "=" * 60)
                print(f"[STARTING MISSION] {i + 1}/{len(race_list)} for '{race_type.upper()}': {event_name}")
                print("=" * 60)

                caching_key = agent.get_caching_key(event_name)
                cache_file_path = os.path.join(KNOWLEDGE_CACHE_DIR, f"{caching_key}.json")
                knowledge_base, is_fresh_run = None, False

                if os.path.exists(cache_file_path):
                    print(f"[INFO] Found knowledge cache for '{caching_key}'. Loading data.")
                    with open(cache_file_path, 'r', encoding='utf-8') as f:
                        knowledge_base = deserialize_knowledge_base(json.load(f))
                else:
                    print(f"[INFO] No knowledge cache found for '{caching_key}'. Running a full analysis.")
                    knowledge_base = agent.run(race_info)
                    is_fresh_run = True

                if knowledge_base:
                    for variant_name, data in knowledge_base.items():
                        if row := format_final_row(event_name, variant_name, data, schema):
                            csv_writers[race_type].writerow(row)
                    csv_writers[race_type].writerow({}) # Add a blank row for separation
                    if is_fresh_run and knowledge_base:
                        print(f"[INFO] Saving new knowledge to cache: {cache_file_path}")
                        with open(cache_file_path, 'w', encoding='utf-8') as f:
                            json.dump(serialize_knowledge_base(knowledge_base), f, indent=4)
                    print(f"[SUCCESS] MISSION COMPLETE FOR: {event_name}")
                else:
                    print(f"[ERROR] MISSION FAILED FOR: {event_name}. No data could be built.")
                    failed_missions.append(event_name)
    except AgentInitializationError as e:
        print(f"[FATAL] A fatal error occurred during agent setup: {e}")
        # Re-raise to ensure streamlit sees a non-zero exit code
        raise
    finally:
        if agent: agent.shutdown()
        for f in output_files.values():
            if f and not f.closed: f.close()

    print("\n" + "=" * 60)
    print("Web Research Analyst Run Complete")
    if failed_missions:
        print("\n[SUMMARY] Failed Missions:")
        for event in failed_missions: print(f"  - {event}")
    else:
        print("\n[SUCCESS] All missions completed successfully.")
    print("=" * 60)


def run_calendar_crawl_mode(output_dir_override=None, max_events=None):
    """
    Original logic from CalendarCrawl. Crawls audaxindia.in for cycling events.
    """
    print("=" * 60)
    print(f"MODE: Calendar Crawl | Version: {APP_VERSION}")
    print("=" * 60)

    agent = None
    failed_missions = []
    effective_output_dir = output_dir_override or OUTPUT_DIR
    schema = CYCLING_SCHEMA

    try:
        agent = MistralAnalystAgent(mistral_key_1=MISTRAL_API_KEY, mistral_key_2=MISTRAL_API_KEY_1,
                                    search_key=SEARCH_API_KEY, cse_id=CSE_ID, schema=schema)

        CALENDAR_URL = "https://www.audaxindia.in/events.php"
        EVENT_TYPE = "Cycling"
        main_page_content = agent._get_content_from_url(CALENDAR_URL)
        if not main_page_content:
            print(f"[FATAL] Could not retrieve content from the calendar URL. Aborting.")
            return

        event_list = []
        organizer_pattern = re.compile(r"^\s*\*\*(?P<city>[^*]+)\*\*\s*(?P<name>[^\[\n\r]+)")
        link_pattern = re.compile(r'\[(?P<details>.*?)\]\((?P<url>.*?)\)')
        for line in main_page_content.splitlines():
            organizer_match = organizer_pattern.match(line)
            if organizer_match:
                city, name = organizer_match.group('city').strip(), organizer_match.group('name').strip()
                current_organizer = f"{city} {name}"
                for link_match in link_pattern.finditer(line):
                    event_list.append(
                        {"organizer": current_organizer, "event_details": link_match.group('details').strip(),
                         "url": urljoin(CALENDAR_URL, link_match.group('url'))})

        if not event_list:
            print("[INFO] No valid event links found on the calendar page after parsing. Aborting.")
            return
        print(f"[SUCCESS] Regex successfully extracted {len(event_list)} total event instances.")

        events_to_process = event_list
        if max_events is not None and max_events > 0:
            events_to_process = events_to_process[:max_events]
            print(f"[INFO] Limiting run to a maximum of {max_events} events.")

        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        output_filename = f"CalendarCrawl_Cycling_{timestamp}.csv"
        output_filepath = os.path.join(effective_output_dir, output_filename)

        with open(output_filepath, 'w', newline='', encoding='utf-8') as output_file:
            writer = csv.DictWriter(output_file, fieldnames=schema)
            writer.writeheader()

            for i, event_info in enumerate(events_to_process):
                event_name = f"{event_info['organizer']} {event_info['event_details']}"
                event_url = event_info['url']
                print("\n" + "=" * 60)
                print(f"[STARTING MISSION] {i + 1}/{len(events_to_process)} FOR: {event_name}")
                print("=" * 60)

                race_info = {"Festival": event_name, "Type": EVENT_TYPE}
                caching_key = agent.get_caching_key(f"{event_name}-{event_url.split('event-e-')[-1]}")
                cache_file_path = os.path.join(KNOWLEDGE_CACHE_DIR, f"{caching_key}.json")
                knowledge_base = None

                if os.path.exists(cache_file_path):
                    with open(cache_file_path, 'r', encoding='utf-8') as f:
                        knowledge_base = deserialize_knowledge_base(json.load(f))
                else:
                    knowledge_base = agent.run_direct(race_info, direct_urls=[event_url])
                    if knowledge_base:
                        with open(cache_file_path, 'w', encoding='utf-8') as f:
                            json.dump(serialize_knowledge_base(knowledge_base), f, indent=4)

                if knowledge_base:
                    main_festival_name = event_info['organizer']
                    for variant_name, data in knowledge_base.items():
                        if row := format_final_row(main_festival_name, variant_name, data, schema):
                            writer.writerow(row)
                    print(f"[SUCCESS] MISSION COMPLETE FOR: {event_name}")
                else:
                    failed_missions.append(event_name)

    except AgentInitializationError as e:
        print(f"[FATAL] A fatal error occurred during agent setup: {e}")
        raise
    finally:
        if agent: agent.shutdown()

    print("\n" + "=" * 60)
    print("Calendar Crawl Complete")
    if failed_missions:
        print("\n[SUMMARY] Failed Missions:")
        for event in failed_missions: print(f"  - {event}")
    else:
        print("\n[SUCCESS] All missions completed successfully.")
    print("=" * 60)

def run_default_websites_mode(input_files, output_dir_override=None, max_events=None):
    """
    Original logic from CalendarCrawl. Processes pre-scraped JSON files.
    """
    print("=" * 60)
    print(f"MODE: Default Websites Processor | Version: {APP_VERSION}")
    print("=" * 60)

    agent = None
    failed_missions = []
    effective_output_dir = output_dir_override or OUTPUT_DIR
    output_files = {}

    try:
        events_data = load_and_process_files(input_files)
        unique_events = {item['link']: item for item in reversed(events_data) if 'link' in item}.values()
        event_list = list(unique_events)
        print(f"[SUCCESS] Extracted {len(event_list)} unique event links from provided files.")

        events_to_process = event_list
        if max_events is not None and max_events > 0:
            events_to_process = events_to_process[:max_events]
            print(f"[INFO] Limiting run to a maximum of {max_events} events.")

        if not events_to_process:
            print("[INFO] No new events to process.")
            return

        schema_map = {"triathlon": TRIATHLON_SCHEMA, "run": RUNNING_SCHEMA, "running": RUNNING_SCHEMA,
                      "trail running": RUNNING_SCHEMA, "swimathon": SWIMMING_SCHEMA, "swimming": SWIMMING_SCHEMA,
                      "duathlon": DUATHLON_SCHEMA, "aquathlon": AQUATHLON_SCHEMA, "aquabike": AQUABIKE_SCHEMA,
                      "cycling": CYCLING_SCHEMA, "fitness racing": FITNESS_RACING_SCHEMA}

        agent = MistralAnalystAgent(mistral_key_1=MISTRAL_API_KEY, mistral_key_2=MISTRAL_API_KEY_1,
                                    search_key=SEARCH_API_KEY, cse_id=CSE_ID, schema=[])

        for i, event_info in enumerate(events_to_process):
            if event_info.get("link") == "BLANK_ROW":
                continue

            event_url = event_info.get("link")
            if not event_url:
                continue

            print("\n" + "=" * 60)
            print(f"[STARTING MISSION] {i + 1}/{len(events_to_process)} FOR: {event_url}")

            event_type = agent.determine_event_type(event_url)
            if not event_type:
                print(f"  - [ERROR] Could not determine event type. Skipping.")
                failed_missions.append(f"{event_url} (Type determination failed)")
                continue

            schema = schema_map.get(event_type.lower())
            if not schema:
                print(f"  - [ERROR] No schema found for type '{event_type}'. Skipping.")
                failed_missions.append(f"{event_url} (No schema for type '{event_type}')")
                continue

            if event_type not in output_files:
                timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
                output_filename = f"DefaultWebsites_{event_type}_{timestamp}.csv"
                output_filepath = os.path.join(effective_output_dir, output_filename)

                f = open(output_filepath, 'w', newline='', encoding='utf-8')
                writer = csv.DictWriter(f, fieldnames=schema)
                writer.writeheader()
                output_files[event_type] = {'file': f, 'writer': writer}

            writer = output_files[event_type]['writer']

            festival_name = event_info.get('festivalName') or event_url
            race_info = {"Festival": festival_name, "Type": event_type}
            pre_filled_data = {k: v for k, v in event_info.items() if k in schema}

            agent.schema = schema
            caching_key = agent.get_caching_key(f"default-event-{event_url}")
            cache_file_path = os.path.join(KNOWLEDGE_CACHE_DIR, f"{caching_key}.json")
            knowledge_base = None

            if os.path.exists(cache_file_path):
                with open(cache_file_path, 'r', encoding='utf-8') as f:
                    knowledge_base = deserialize_knowledge_base(json.load(f))
            else:
                knowledge_base = agent.run_direct(race_info, direct_urls=[event_url], pre_filled_data=pre_filled_data)
                if knowledge_base:
                    with open(cache_file_path, 'w', encoding='utf-8') as f:
                        json.dump(serialize_knowledge_base(knowledge_base), f, indent=4)

            if knowledge_base:
                for variant_name, data in knowledge_base.items():
                    if row := format_final_row(festival_name, variant_name, data, schema):
                        row['eventWebsite'] = event_url
                        writer.writerow(row)
                print(f"[SUCCESS] MISSION COMPLETE FOR: {festival_name}")
            else:
                failed_missions.append(f"{event_url} (No data extracted)")

    except AgentInitializationError as e:
        print(f"[FATAL] A fatal error occurred during agent setup: {e}")
        raise
    finally:
        if agent: agent.shutdown()
        for f_info in output_files.values():
            if f_info and not f_info['file'].closed:
                f_info['file'].close()

    print("\n" + "=" * 60)
    print("Default Websites Run Complete")
    if failed_missions:
        print("\n[SUMMARY] Failed Missions:")
        for event in failed_missions: print(f"  - {event}")
    else:
        print("\n[SUCCESS] All missions completed successfully.")
    print("=" * 60)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Crawl4AI Unified Agent Backend")
    parser.add_argument("--mode", type=str, required=True, choices=['web_analyst', 'calendar_crawl', 'default_websites'], help="The agent mode to run.")
    parser.add_argument("--output-dir", type=str, default=OUTPUT_DIR, help="Directory to save output files.")
    parser.add_argument("--input-file", type=str, help="Path to a single input file (for web_analyst mode).")
    parser.add_argument("--input-files", nargs='+', help="List of input files (for default_websites mode).")
    parser.add_argument("--max-events", type=int, help="Maximum number of events to process.")
    args = parser.parse_args()

    for dir_path in [args.output_dir, CRAWL_CACHE_DIR, KNOWLEDGE_CACHE_DIR]:
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)

    if args.mode == 'web_analyst':
        if not args.input_file:
            print("[ERROR] --input-file is required for web_analyst mode.")
        else:
            run_web_analyst_mode(
                input_file_path=args.input_file,
                output_dir_override=args.output_dir,
                max_events=args.max_events
            )
    elif args.mode == 'calendar_crawl':
        run_calendar_crawl_mode(
            output_dir_override=args.output_dir,
            max_events=args.max_events
        )
    elif args.mode == 'default_websites':
        if not args.input_files:
            print("[ERROR] --input-files are required for default_websites mode.")
        else:
            run_default_websites_mode(
                input_files=args.input_files,
                output_dir_override=args.output_dir,
                max_events=args.max_events
            )