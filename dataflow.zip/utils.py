# utils.py

import os
import re
import csv
import json
import ftfy
from datetime import datetime
from dateutil.parser import parse as date_parse

from schemas import DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS
from config import MIN_CONFIDENCE_THRESHOLD
from agent import Field

def serialize_knowledge_base(knowledge_base: dict) -> dict:
    serializable_kb = {}
    for variant, data in knowledge_base.items():
        serializable_kb[variant] = {field_name: field_obj.to_dict() for field_name, field_obj in data.items()}
    return serializable_kb

def deserialize_knowledge_base(cached_data: dict) -> dict:
    knowledge_base = {}
    for variant, data in cached_data.items():
        knowledge_base[variant] = {
            field_name: Field.from_dict(field_data) for field_name, field_data in data.items()
        }
    return knowledge_base

class SafeCSVWriter:
    """
    A context manager wrapper for CSV writing that enforces append-only logic
    and immediate flushing to prevent data loss.
    """
    def __init__(self, filepath, schema):
        self.filepath = filepath
        self.schema = schema
        self.file = None
        self.writer = None

    def __enter__(self):
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(self.filepath), exist_ok=True)
        
        file_exists = os.path.isfile(self.filepath) and os.path.getsize(self.filepath) > 0
        self.file = open(self.filepath, 'a', newline='', encoding='utf-8')
        self.writer = csv.DictWriter(self.file, fieldnames=self.schema)
        
        if not file_exists:
            self.writer.writeheader()
            self.file.flush()
        
        return self

    def writerow(self, row):
        if self.writer:
            self.writer.writerow(row)
            self.file.flush()

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.file:
            self.file.close()

def normalize_restricted_traffic(value: str) -> str:
    """Strictly normalizes restrictedTraffic to 'Yes' or 'No'."""
    if not value:
        return "No"
    v = value.lower().strip()
    if v in ['yes', 'true', '1', 'restricted']:
        return "Yes"
    return "No"

def validate_row_integrity(row: dict, schema: list) -> bool:
    """
    Validates a formatted row.
    Relaxed to ensure rows aren't dropped unnecessarily.
    """
    # Rule 1: Event Name is the ONLY hard requirement.
    if 'event' in schema and not row.get('event'):
        print(f"  [VALIDATION FAIL] Missing 'event' field.")
        return False

    # Rule 2: Date sanity check (if present, must not be gibberish)
    # If date is invalid, we clear it but KEEP the row.
    if row.get('date'):
        # Just ensure it doesn't look like code or a URL
        if len(row['date']) > 50 or "http" in row['date']:
            row['date'] = ""

    return True

def format_final_row(festival_name_input: str, variant_name: str, data: dict, schema: list) -> dict | None:
    
    def normalize_complex_value(val):
        """Recursively extracts the primary value from nested dictionaries/lists."""
        if isinstance(val, str):
            if val.strip().startswith('{') and val.strip().endswith('}'):
                try:
                    val = json.loads(val)
                except json.JSONDecodeError:
                    return val
            else:
                return val
        
        if isinstance(val, dict):
            for key in ['amount', 'value', 'price', 'final', 'standard']:
                if key in val: return normalize_complex_value(val[key])
            for v in val.values():
                if isinstance(v, (int, float)) or (isinstance(v, str) and v.replace('.', '', 1).isdigit()):
                    return normalize_complex_value(v)
            return normalize_complex_value(list(val.values())[0]) if val else ""
            
        if isinstance(val, list):
            for item in val:
                extracted = normalize_complex_value(item)
                if extracted: return extracted
            return ""
        return str(val) if val is not None else ""

    def get_value(field_name: str) -> any:
        field_obj = data.get(field_name)
        if not isinstance(field_obj, Field): return ""
        
        # CRITICAL FIX: If inferred_by is 'pre_processed_data', ALLOW IT regardless of threshold.
        # This fixes the issue where pre-filled data (0.3 confidence) was being hidden.
        if field_obj.inferred_by == 'pre_processed_data':
            return field_obj.value

        min_thresh = 0.4 if "inference" in field_obj.inferred_by else MIN_CONFIDENCE_THRESHOLD
        if field_obj.confidence >= min_thresh:
            return field_obj.value
        return ""

    def finalize_value(value: any) -> str:
        value = normalize_complex_value(value)
        text = ftfy.fix_text(str(value)).strip()
        if text.lower() in ["na", "n/a", "", "none", "not specified", "null", "unknown"]: return ""
        return text

    row = {}
    for key in schema:
        if key in DEFAULT_BLANK_FIELDS:
            row[key] = ""
            continue
        
        raw_value = finalize_value(get_value(key))
        
        if key == "city":
            row[key] = raw_value.split(',')[0].strip()
            
        elif key == "registrationCost":
             cleaned = re.sub(r'[^\d.]', '', raw_value)
             row[key] = cleaned
             
        elif key in ["runningDistance", "cyclingDistance", "swimDistance"]:
             match = re.search(r'(\d+\.?\d*)', raw_value)
             row[key] = match.group(1) if match else raw_value
             
        elif key in ["date", "lastDate"]:
            # Robust Date Parsing
            if re.match(r"\d{4}-\d{2}-\d{2}", raw_value):
                try:
                    row[key] = datetime.strptime(raw_value, "%Y-%m-%d").strftime("%d/%m/%Y")
                except ValueError:
                    row[key] = raw_value # Keep raw if conversion fails
            elif re.match(r"\d{2}/\d{2}/\d{4}", raw_value):
                 row[key] = raw_value
            else:
                try:
                    dt = date_parse(raw_value, fuzzy=True, dayfirst=True)
                    if dt.year >= 2020:
                        row[key] = dt.strftime("%d/%m/%Y")
                    else:
                        row[key] = raw_value # Keep raw if year is weird
                except (ValueError, TypeError):
                    row[key] = raw_value # Keep raw rather than empty
                    
        elif key == "restrictedTraffic":
            row[key] = normalize_restricted_traffic(raw_value)
            
        else:
            row[key] = raw_value

    if festival_name_input and festival_name_input.lower() not in variant_name.lower():
        row["event"] = f"{festival_name_input} - {variant_name}"
    else:
        row["event"] = variant_name

    if not row.get("organiser") and festival_name_input:
        row["organiser"] = festival_name_input

    if row.get("date"):
        try:
            # Only try to fill these if date parses correctly, otherwise leave blank
            dt = datetime.strptime(row["date"], "%d/%m/%Y")
            row["month"] = dt.strftime("%B")
            row["editionYear"] = str(dt.year)
        except: pass

    if not row.get("approvalStatus"): row["approvalStatus"] = "Approved"

    # Validation
    if not validate_row_integrity(row, schema):
        return None

    return row