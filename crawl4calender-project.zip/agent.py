# agent.py
# This file contains the core logic for the Crawl4AI Mistral Analyst Agent.

import os
import re
import json
import time
import hashlib
import sys
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import wraps
from urllib.parse import urljoin

import requests
import ftfy
import numpy as np
import dirtyjson
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer, CrossEncoder
from langchain_mistralai.chat_models import ChatMistralAI
from langchain_core.messages import HumanMessage

from markdown_it import MarkdownIt
from readability import Document
from lxml import etree
from rank_bm25 import BM25Okapi

import spacy

from config import (
    MISTRAL_MODEL, MAX_RETRIES, DEBUG, MAX_CONCURRENT_CRAWLERS,
    TOP_N_URLS_TO_PROCESS, CRAWL_CACHE_DIR, EMBEDDING_MODEL, SPACY_MODEL,
    VECTOR_DB_PATH, CROSS_ENCODER_MODEL, RAG_CANDIDATE_POOL_SIZE,
    RAG_FINAL_EVIDENCE_COUNT, MIN_CONFIDENCE_THRESHOLD
)
from schemas import (
    DEFAULT_BLANK_FIELDS, CHOICE_OPTIONS, INFERABLE_FIELDS, BLACKLISTED_DOMAINS
)

# Custom Exception for robust error handling
class AgentInitializationError(Exception):
    pass

def retry(retries=MAX_RETRIES, delay=5):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            for i in range(retries):
                try:
                    return f(*args, **kwargs)
                except Exception as e:
                    if i < retries - 1:
                        is_rate_limit = "429" in str(e)
                        current_delay = delay * (2 ** i) if not is_rate_limit else delay * (3 ** i)
                        print(f"⚠️  Function '{f.__name__}' failed. Retrying in {current_delay:.1f}s...")
                        time.sleep(current_delay)
                    else:
                        print(f"❌  Function '{f.__name__}' failed after {retries} retries.");
                        return None

        return wrapper

    return decorator


class Field:
    def __init__(self, value=None, confidence=0.0, sources=None, inferred_by=""):
        self.value, self.confidence, self.sources, self.inferred_by = value, confidence, sources or [], inferred_by
        self.last_updated = datetime.now(timezone.utc).isoformat()

    def to_dict(self):
        return {"value": self.value, "confidence": self.confidence, "sources": self.sources,
                "inferred_by": self.inferred_by, "last_updated": self.last_updated}


class MistralAnalystAgent:
    def __init__(self, mistral_key: str, search_key: str, cse_id: str, schema: list):
        if not all([mistral_key, search_key, cse_id]): raise ValueError("API keys missing.")
        self.llm_client = ChatMistralAI(api_key=mistral_key, model=MISTRAL_MODEL, temperature=0.0)
        self.search_api_key, self.cse_id, self.schema = search_key, cse_id, schema
        self.field_instructions = self._generate_field_instructions()
        self.invalid_years = [str(y) for y in range(2015, 2025)]

        print("🚀 Initializing ML models and VectorDB...")
        try:
            # This check is crucial for running in different environments (like bundled apps)
            if getattr(sys, 'frozen', False):
                base_path = sys._MEIPASS
                model_path = os.path.join(base_path, SPACY_MODEL)
                if not os.path.isdir(model_path): raise IOError(f"Bundled spaCy model not found: {model_path}")
                self.nlp = spacy.load(model_path)
            else:
                self.nlp = spacy.load(SPACY_MODEL)
            print("  - ✅ spaCy model loaded successfully.")
        except (OSError, IOError) as e:
            # --- BUG FIX ---
            # Replaced sys.exit(1) with a proper exception.
            # This prevents the thread from silently dying and allows the UI to report the error.
            error_msg = (f"❌ FATAL: Failed to load spaCy model '{SPACY_MODEL}'. "
                         f"Please run 'python -m spacy download en_core_web_sm'. Error: {e}")
            raise AgentInitializationError(error_msg)

        self.chroma_client = chromadb.Client(
            Settings(persist_directory=VECTOR_DB_PATH, anonymized_telemetry=False, is_persistent=True, allow_reset=True)
        )

        self.embedding_model = SentenceTransformer(EMBEDDING_MODEL)
        self.cross_encoder = CrossEncoder(CROSS_ENCODER_MODEL)
        self.md_parser = MarkdownIt()
        self.chroma_collection = None
        self.bm25_index, self.mission_corpus, self.corpus_map = None, [], {}
        self.mission_inference_cache = {}
        print("✅ Models and VectorDB initialized.")

    def shutdown(self):
        """Resets the ChromaDB client to release file locks."""
        print("  - Shutting down ChromaDB client...")
        try:
            self.chroma_client.reset()
            print("  - ChromaDB client reset successfully.")
        except Exception as e:
            print(f"  - ⚠️ Error while shutting down ChromaDB client: {e}")

    def get_caching_key(self, event_name: str) -> str:
        base_name = re.sub(r'sprint|standard|olympic|full iron|half iron|70\.3', '', event_name, flags=re.IGNORECASE)
        return re.sub(r'[^a-z0-9]+', '-', base_name.lower()).strip('-')

    def _generate_field_instructions(self) -> dict:
        instructions = {}
        for key in self.schema:
            if key in DEFAULT_BLANK_FIELDS: continue
            if key in CHOICE_OPTIONS:
                instructions[key] = f"Extract the data for '{key}'. MUST be one of: {', '.join(CHOICE_OPTIONS[key])}."
            else:
                instructions[key] = f"Extract the data for '{key}'."
        return instructions

    @retry()
    def _call_llm(self, prompt: str) -> str:
        messages = [HumanMessage(content=prompt)]
        response = self.llm_client.invoke(messages)
        return response.content

    def _sanitize_markdown_content(self, content: str) -> str:
        """Cleans up complex nested markdown like **_text_** into just text."""
        sanitized_content = content
        for _ in range(5):
            sanitized_content = re.sub(r'\*\*\_(.*?)\_\*\*', r'\1', sanitized_content)
        sanitized_content = sanitized_content.replace('**', '').replace('__', '')
        sanitized_content = re.sub(r'\s{2,}', ' ', sanitized_content)
        return sanitized_content

    def determine_event_type(self, url: str) -> str | None:
        """Crawls a URL and asks the LLM to classify the event type."""
        print(f"  - Determining event type for URL: {url}")
        content = self._get_content_from_url(url)
        if not content:
            print("    - ❌ Could not fetch content to determine type.")
            return None

        valid_types = ", ".join(CHOICE_OPTIONS["type"])
        prompt = f"Analyze the text from a webpage and determine the type of athletic event. Your answer MUST be one of: {valid_types}.\n\nWebpage Text:\n---\n{content[:4000]}\n---"
        try:
            response_text = self._call_llm(prompt)
            if not response_text:
                print("    - ⚠️ LLM call for event type determination failed.")
                return None

            response = response_text.strip()
            for event_type in CHOICE_OPTIONS["type"]:
                if event_type.lower() in response.lower():
                    print(f"    - ✅ Determined event type: {event_type}")
                    return event_type
            print(f"    - ⚠️ LLM response '{response}' did not match a valid type.")
            return None
        except Exception as e:
            print(f"    - ❌ Error during event type determination: {e}")
            return None

    @retry(retries=2, delay=10)
    def _get_content_from_url(self, url: str) -> str | None:
        url_hash = hashlib.md5(url.encode()).hexdigest()
        cache_path = os.path.join(CRAWL_CACHE_DIR, f"{url_hash}.md")
        if os.path.exists(cache_path):
            if DEBUG: print(f"  - Using cached content for: {url}")
            with open(cache_path, 'r', encoding='utf-8') as f:
                return f.read()

        print(f"  - Crawling: {url}")
        try:
            api_url = f"https://r.jina.ai/{url}"
            response = requests.get(api_url, timeout=60)

            if response.status_code == 200 and response.text:
                sanitized_content = self._sanitize_markdown_content(response.text)
                with open(cache_path, 'w', encoding='utf-8') as f:
                    f.write(sanitized_content)
                return sanitized_content
            else:
                print(f"  - ⚠️  Jina crawl failed with status {response.status_code}. Response: {response.text}")
                return None
        except requests.RequestException as e:
            print(f"  - ❌ Jina crawl failed for {url}: {e}")
        return None

    def _chunk_and_index_text(self, text: str, url: str, event_id_str: str):
        chunks = self._chunk_markdown_with_ast(text)
        if not chunks: return
        print(f"    - Semantically chunked into {len(chunks)} passages from {url}")
        chunk_ids = [f"{event_id_str}_{hashlib.md5(chunk.encode()).hexdigest()}" for chunk in chunks]
        unique_chunk_ids, new_chunks_to_add, added_chunk_content = list(set(chunk_ids)), [], set()
        existing_ids = set(self.chroma_collection.get(ids=unique_chunk_ids)['ids'])
        for i, chunk_id in enumerate(chunk_ids):
            chunk_content = chunks[i]
            if chunk_id not in existing_ids and chunk_content not in added_chunk_content:
                new_chunks_to_add.append({'id': chunk_id, 'chunk': chunk_content})
                added_chunk_content.add(chunk_content)
        if not new_chunks_to_add: print("    - All passages from this URL are already in the VectorDB."); return
        print(f"    - Found {len(new_chunks_to_add)} new unique passages to index.")
        new_ids = [item['id'] for item in new_chunks_to_add]
        new_documents = [item['chunk'] for item in new_chunks_to_add]
        new_embeddings = self.embedding_model.encode(new_documents).tolist()
        new_metadatas = [{"source_url": url, "event_id": event_id_str} for _ in new_ids]
        self.chroma_collection.add(ids=new_ids, embeddings=new_embeddings, documents=new_documents,
                                   metadatas=new_metadatas)
        self.mission_corpus.extend(new_documents)

    def _chunk_markdown_with_ast(self, markdown_text: str) -> list[str]:
        try:
            tokens = self.md_parser.parse(markdown_text)
        except Exception:
            from langchain_text_splitters import RecursiveCharacterTextSplitter
            return RecursiveCharacterTextSplitter(chunk_size=512, chunk_overlap=64).split_text(markdown_text)
        chunks, current_chunk = [], ""
        for token in tokens:
            if token.type.endswith('_open') and token.tag in ['h1', 'h2', 'h3']:
                if current_chunk: chunks.append(current_chunk.strip())
                current_chunk = ""
            if token.content: current_chunk += token.content + "\n"
            if token.type.startswith('table_'):
                if current_chunk and not token.type.endswith('_close'): chunks.append(current_chunk.strip())
                current_chunk = ""
        if current_chunk: chunks.append(current_chunk.strip())
        return [c for c in chunks if c]

    def _retrieve_and_fuse_evidence(self, query: str, top_k: int) -> list[dict]:
        bm25_results = []
        if self.bm25_index and self.mission_corpus:
            doc_scores = self.bm25_index.get_scores(query.lower().split())
            top_n_indices = np.argsort(doc_scores)[::-1][:top_k]
            bm25_results = [self.corpus_map[i] for i in top_n_indices]
        collection_count = self.chroma_collection.count()
        n_results = min(top_k, collection_count)
        hnsw_results = []
        if n_results > 0:
            query_embedding = self.embedding_model.encode(query).tolist()
            chroma_results_set = self.chroma_collection.query(query_embeddings=[query_embedding], n_results=n_results)
            hnsw_results = [{"id": _id, "snippet": doc} for _id, doc in
                            zip(chroma_results_set['ids'][0], chroma_results_set['documents'][0])]
        fused_scores, k = {}, 60
        all_results = {item['id']: item for item in bm25_results + hnsw_results}
        for rank, item in enumerate(bm25_results):
            if item['id'] not in fused_scores: fused_scores[item['id']] = 0; fused_scores[item['id']] += 1 / (
                    k + rank + 1)
        for rank, item in enumerate(hnsw_results):
            if item['id'] not in fused_scores: fused_scores[item['id']] = 0; fused_scores[item['id']] += 1 / (
                    k + rank + 1)
        if not fused_scores: return []
        sorted_fused = sorted(fused_scores.items(), key=lambda i: i[1], reverse=True)
        return [all_results[doc_id] for doc_id, score in sorted_fused[:top_k]]

    def _rerank_evidence_with_cross_encoder(self, query: str, evidence: list[dict]) -> list[dict]:
        if not evidence: return []
        pairs = [(query, item['snippet']) for item in evidence]
        scores = self.cross_encoder.predict(pairs)
        for i, item in enumerate(evidence):
            item['rerank_score'] = float(scores[i])
        return sorted(evidence, key=lambda x: x['rerank_score'], reverse=True)

    def _update_knowledge_base_with_rag(self, knowledge_base: dict, event_name: str, variant_name: str):
        print(f"    - Pass 1: Performing holistic RAG extraction for '{variant_name}'...")

        all_fields_query = f"Extract all available information for the event '{event_name}', specifically for the '{variant_name}' category."
        candidate_evidence = self._retrieve_and_fuse_evidence(all_fields_query, top_k=RAG_CANDIDATE_POOL_SIZE)
        reranked_evidence = self._rerank_evidence_with_cross_encoder(all_fields_query, candidate_evidence)
        final_evidence = reranked_evidence[:RAG_FINAL_EVIDENCE_COUNT + 5]

        if not final_evidence:
            print("      - ⚠️ No relevant evidence found for holistic extraction.")
            return knowledge_base

        evidence_prompt = "\n".join([f"Evidence Snippet:\n---\n{e['snippet']}\n---" for e in final_evidence])

        fields_to_extract = [f"- {key}: {desc}" for key, desc in self.field_instructions.items()]
        fields_prompt = "\n".join(fields_to_extract)

        prompt = f"""
        You are an expert data analyst with extreme attention to detail. Your task is to extract all specified fields for the event based ONLY on the provided evidence.
        - Analyze the combined evidence to understand the full context.
        - The primary focus is on the '{variant_name}' category of the '{event_name}' event.
        - Do NOT guess or infer information not present. If a value is not found, omit the key or set it to null.

        ## Task
        Extract the following data points and return them in a single, flat JSON object.
        {fields_prompt}

        ## Evidence
        {evidence_prompt}

        ## Response Format
        Respond with a single JSON object. Example: {{"city": "Mumbai", "date": "21/09/2025", "runningDistance": "10"}}
        """

        response_text = self._call_llm(prompt)
        try:
            match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if not match:
                if DEBUG: print(f"      - ⚠️  Holistic extraction did not return valid JSON.")
                return knowledge_base

            extracted_data = dirtyjson.loads(match.group(0))
            print(f"      - ✨ Holistic extraction successful. Found {len(extracted_data)} data points.")

            confidence = 0.90
            for key, value in extracted_data.items():
                if key in self.schema and value:
                    if knowledge_base[variant_name].get(key, Field()).confidence < confidence:
                        value_str = json.dumps(value) if isinstance(value, (dict, list)) else str(value)
                        knowledge_base[variant_name][key] = Field(value=value_str, confidence=confidence,
                                                                  sources=final_evidence,
                                                                  inferred_by="rag_llm_holistic")

        except (dirtyjson.error.Error, AttributeError, TypeError, ValueError) as e:
            if DEBUG: print(f"      - ⚠️  Holistic LLM response parsing failed: {e}.")

        return knowledge_base

    def _discover_and_validate_variants_from_content(self, content: str, knowledge_base: dict):
        """Uses LLM to find all race categories/distances from the crawled content."""
        print("    - Discovering all race variants from content...")
        prompt = f"""
        You are a race event analyst. Your task is to identify all distinct, registerable race categories or distances mentioned in the text.
        Scan the entire text for sections related to 'Registration', 'Categories', 'Race Options', 'Distances', or 'Tickets'.
        CRITICAL INSTRUCTION: Ignore distances mentioned in general descriptions, sponsor lists, or examples of past events. Only extract the specific, individual race options a user can choose from.
        Return ONLY a simple JSON list of the names of these variants.

        Example:
        ["10K Timed Run", "5K Fun Run", "Half Marathon"]

        Text to analyze:
        ---
        {content[:15000]}
        ---
        """
        response_text = self._call_llm(prompt)
        try:
            match = re.search(r'\[.*\]', response_text, re.DOTALL)
            if match:
                variants = json.loads(match.group(0))
                if isinstance(variants, list) and all(isinstance(v, str) for v in variants):
                    cleaned_variants = [v for v in variants if len(v) < 100]
                    print(f"      - ✅ Found {len(cleaned_variants)} variants: {', '.join(cleaned_variants)}")
                    for variant_name in cleaned_variants:
                        if variant_name not in knowledge_base:
                            knowledge_base[variant_name] = {field: Field() for field in self.schema}
                    return
        except (json.JSONDecodeError, TypeError) as e:
            if DEBUG: print(f"      - ⚠️  Could not parse variant list from LLM response: {e}")

        print("      - ⚠️  Variant discovery failed or returned no results.")

    def _run_targeted_gap_filling(self, knowledge_base: dict, full_content: str):
        """Pass 2: Uses full page content to fill critical gaps left by the RAG process."""
        print("    - Pass 2: Running targeted full-context extraction for critical gaps...")
        CRITICAL_FIELDS_FOR_GAP_FILL = ['date', 'city', 'registrationCost', 'organiser']

        for variant_name, data in knowledge_base.items():
            for field in CRITICAL_FIELDS_FOR_GAP_FILL:
                if field in self.schema and not data.get(field, Field()).value:
                    print(f"      - Targeting missing field '{field}' for variant '{variant_name}'...")

                    prompt = f"""
                    You are a data extraction expert. From the ENTIRE text provided below, find the exact value for the field '{field}' for the '{variant_name}' race category.
                    - Do NOT guess. If the specific information is not found, return a JSON object with the answer as null.
                    - Focus only on the '{field}'.

                    ## Full Text
                    ---
                    {full_content}
                    ---

                    ## Response Format
                    Return a single JSON object with one key, 'answer', containing the found value. Example: {{"answer": "21/09/2025"}}
                    """
                    response_text = self._call_llm(prompt)
                    try:
                        match = re.search(r'\{.*\}', response_text, re.DOTALL)
                        if match:
                            result = dirtyjson.loads(match.group(0))
                            answer = result.get('answer')
                            if answer:
                                print(f"        - ✅ Found '{field}': {answer}")
                                knowledge_base[variant_name][field] = Field(value=str(answer), confidence=0.95,
                                                                            inferred_by="full_context_gap_fill")
                    except Exception as e:
                        if DEBUG: print(f"      - ⚠️ Gap-fill parsing failed for '{field}': {e}")
        return knowledge_base

    def _inject_pre_filled_data(self, knowledge_base: dict, pre_filled_data: dict):
        """Injects data from pre-processing into the knowledge base with high confidence."""
        if not pre_filled_data:
            return

        print("    - Injecting pre-filled data...")
        for variant_name in knowledge_base.keys():
            for key, value in pre_filled_data.items():
                if key in self.schema and value:
                    if knowledge_base[variant_name].get(key, Field()).confidence < 0.98:
                        print(f"      - ✅ Injecting '{key}' for variant '{variant_name}'.")
                        knowledge_base[variant_name][key] = Field(value=str(value), confidence=0.98,
                                                                  inferred_by="pre_processed_data")

    def _pre_populate_from_name(self, event_name: str, knowledge_base: dict):
        """Intelligently parse the event name to pre-populate fields with high confidence."""
        print(f"    - Pre-populating data from variant name: '{event_name}'...")

        distance = None
        lower_event_name = event_name.lower()

        if 'half marathon' in lower_event_name or 'hm' in lower_event_name:
            distance = '21.1'
        elif 'marathon' in lower_event_name:
            distance = '42.2'

        if distance is None:
            distance_match = re.search(r'(\d+\.?\d*)\s*k', lower_event_name)
            if distance_match:
                dist_val = float(distance_match.group(1))
                if 1 <= dist_val <= 200:
                    distance = str(dist_val)

        if distance:
            field_name = None
            if 'cyclingDistance' in self.schema:
                field_name = 'cyclingDistance'
            elif 'runningDistance' in self.schema:
                field_name = 'runningDistance'

            if field_name and not knowledge_base[event_name].get(field_name, Field()).value:
                print(f"      - ✅ Pre-computed distance from title: {distance}km. Populating '{field_name}'.")
                knowledge_base[event_name][field_name] = Field(value=distance, confidence=0.97,
                                                               inferred_by="pre-computation_from_title")

    def _run_inferential_filling(self, knowledge_base: dict):
        print("\n[INFERENCE] Running final analysis to infer missing data...")
        sample_city = None
        for data in knowledge_base.values():
            city_field = data.get("city")
            if city_field and city_field.value and city_field.confidence > 0.7:
                sample_city = city_field.value.split(',')[0].strip()
                break

        if not sample_city:
            print("  - ⚠️ Skipping inference, no confident city found.")
            return knowledge_base

        for field_name in INFERABLE_FIELDS:
            cache_key = (sample_city, field_name)
            if cache_key in self.mission_inference_cache:
                inferred_value = self.mission_inference_cache[cache_key]
                print(f"  - Using cached inference for '{field_name}' in '{sample_city}': {inferred_value}")
            else:
                print(f"  - Inferring '{field_name}' for city '{sample_city}'...")
                prompt = ""
                if field_name == 'country':
                    prompt = f"What country is the city of '{sample_city}' in? Respond with ONLY the country name."
                elif 'Elevation' in field_name:
                    options = ", ".join(CHOICE_OPTIONS.get(field_name, []))
                    if options: prompt = f"Considering the general topography of '{sample_city}', what is the most likely course elevation profile? Answer MUST be one of: {options}."

                if not prompt: continue

                inferred_value_raw = self._call_llm(prompt)
                if not inferred_value_raw:
                    print(f"    - ⚠️ LLM call for inference of '{field_name}' failed.")
                    continue

                inferred_value = inferred_value_raw.strip().replace('"', '')
                if 'Elevation' in field_name:
                    for option in CHOICE_OPTIONS.get(field_name, []):
                        if option.lower() in inferred_value.lower():
                            inferred_value = option
                            break

                print(f"    - Inferred value: {inferred_value}")
                self.mission_inference_cache[cache_key] = inferred_value

            if inferred_value:
                for variant_name, data in knowledge_base.items():
                    if field_name in self.schema and not data.get(field_name, Field()).value:
                        knowledge_base[variant_name][field_name] = Field(value=inferred_value, confidence=0.5,
                                                                         inferred_by="llm_inference_cached")
        return knowledge_base

    def run(self, race_info: dict, direct_urls: list = None, pre_filled_data: dict = None) -> dict:
        event_name = race_info.get("Festival")

        if not direct_urls:
            print("❌ This agent mode requires direct URLs. Aborting.")
            return None

        print(f"\n[STEP 1] Using {len(direct_urls)} directly provided URL(s) for '{event_name}'.")
        validated_urls = [url for url in direct_urls if self._is_valid_url(url)]

        if not validated_urls:
            print("  - ❌ No valid URLs to process. Aborting mission for this event.")
            return None

        return self._crawl_and_extract(validated_urls, race_info, pre_filled_data)

    def _is_valid_url(self, url: str) -> bool:
        if url.lower().endswith('.pdf'):
            if DEBUG: print(f"  - Skipping PDF link: {url}")
            return False
        if any(year in url for year in self.invalid_years):
            if DEBUG: print(f"  - Filtering out past year URL: {url}")
            return False
        return True

    def _crawl_and_extract(self, urls: list, race_info: dict, pre_filled_data: dict = None) -> dict:
        event_name = race_info.get("Festival")

        if event_name.startswith('http'):
            event_id_str = hashlib.md5(event_name.encode()).hexdigest()
        else:
            event_id_str = self.get_caching_key(event_name)

        self.chroma_collection = self.chroma_client.get_or_create_collection(name=event_id_str)
        print(f"\n[STEP 2] Starting RAG processing for '{event_name}' (Collection: {event_id_str})")
        knowledge_base = {}
        self.mission_corpus, self.corpus_map, self.bm25_index = [], {}, None

        all_content = []
        with ThreadPoolExecutor(max_workers=MAX_CONCURRENT_CRAWLERS) as executor:
            futures = {executor.submit(self._get_content_from_url, url): url for url in urls}
            for future in as_completed(futures):
                if content := future.result():
                    url = futures[future]
                    all_content.append(content)
                    print(f"  - Processing content from: {url}")
                    self._chunk_and_index_text(content, url, event_id_str)

        if not all_content:
            print("  - ⚠️ No content could be crawled from any URL. Aborting.")
            return {}

        combined_content = "\n\n".join(all_content)
        self._discover_and_validate_variants_from_content(combined_content, knowledge_base)

        if not knowledge_base:
            print("      - ⚠️ Variant discovery failed. Falling back to primary event name.")
            knowledge_base[event_name] = {field: Field() for field in self.schema}

        if pre_filled_data:
            self._inject_pre_filled_data(knowledge_base, pre_filled_data)

        for variant in knowledge_base.keys():
            self._pre_populate_from_name(variant, knowledge_base)

        all_docs = self.chroma_collection.get()
        self.mission_corpus = all_docs.get('documents', [])
        if self.mission_corpus:
            print(f"  - Building BM25 index for {len(self.mission_corpus)} total passages...")
            self.bm25_index = BM25Okapi([doc.lower().split() for doc in self.mission_corpus])
            self.corpus_map = {i: {'id': all_docs['ids'][i], 'snippet': doc} for i, doc in
                               enumerate(self.mission_corpus)}

        for variant in list(knowledge_base.keys()):
            self._update_knowledge_base_with_rag(knowledge_base, event_name, variant)

        self._run_targeted_gap_filling(knowledge_base, combined_content)

        knowledge_base = self._run_inferential_filling(knowledge_base)
        print("\n✅ All search and analysis phases complete.")
        return knowledge_base